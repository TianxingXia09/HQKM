"""Unit tests. Run with ``python -m pytest tests`` or, with no pytest installed,
``python -m unittest discover -s tests`` -- both work."""

from __future__ import annotations

import sys
import unittest
from unittest import mock
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from hqkm import (EncodingConfig, ModelConfig, SketchConfig, ALL_MODELS,
                  build_dictionary, build_model, classification_metrics,
                  effective_dimension, load_dataset, make_splits,
                  normalize_gram, product_kernel, quantum_kernel_fn,
                  redundancy_certificate, benefit_criterion)
from hqkm.estimator import (ProgressiveNystrom, executions_exact,
                            executions_sketch, nystrom_sketch)
from hqkm.protocol import ProtocolConfig, run_single
from hqkm.metrics import paired_t_test, wilcoxon_signed_rank
from hqkm.utility_gate import evaluate_gate, select_eta, utility_score


class TestQuantum(unittest.TestCase):
    def test_product_kernel_is_psd_and_bounded(self):
        rng = np.random.default_rng(0)
        X = rng.uniform(-np.pi, np.pi, (40, 6))
        K = product_kernel(X, X)
        self.assertTrue(np.allclose(K, K.T))
        self.assertGreaterEqual(float(np.linalg.eigvalsh(K).min()), -1e-10)
        self.assertTrue(((K >= -1e-12) & (K <= 1 + 1e-12)).all())
        self.assertTrue(np.allclose(np.diag(K), 1.0))

    def test_shots_interpolate_to_exact(self):
        rng = np.random.default_rng(1)
        X = rng.uniform(-np.pi, np.pi, (30, 4))
        K = quantum_kernel_fn(EncodingConfig(4))(X)
        noisy64 = nystrom_sketch(quantum_kernel_fn(EncodingConfig(4)), X,
                                 SketchConfig(m=30, shots=64,
                                              psd_repair=False), rng).gram
        self.assertLess(float(np.linalg.norm(noisy64 - K)
                              / np.linalg.norm(K)), 0.5)


class TestEstimator(unittest.TestCase):
    def test_execution_accounting(self):
        self.assertEqual(executions_exact(100, 10), 10 * 100 * 101 / 2)
        self.assertEqual(executions_sketch(100, 20, 10),
                         10 * (100 * 20 + 20 * 21 / 2))

    def test_tau_rule_bigger_shots_smaller_threshold(self):
        X = np.random.default_rng(0).uniform(-1, 1, (50, 4))
        qfn = quantum_kernel_fn(EncodingConfig(4))
        a = nystrom_sketch(qfn, X, SketchConfig(m=20, shots=200), np.random.default_rng(0))
        b = nystrom_sketch(qfn, X, SketchConfig(m=20, shots=2000), np.random.default_rng(0))
        self.assertGreater(a.tau_trunc, b.tau_trunc)

    def test_sketch_error_decreases_with_budget(self):
        rng = np.random.default_rng(2)
        X = rng.uniform(-np.pi, np.pi, (120, 5))
        qfn = quantum_kernel_fn(EncodingConfig(5))
        K = normalize_gram(qfn(X))
        errs = []
        for m, s in ((30, 200), (60, 2000)):
            res = nystrom_sketch(qfn, X, SketchConfig(m=m, shots=s), rng)
            errs.append(np.linalg.norm(normalize_gram(res.gram) - K)
                        / np.linalg.norm(K))
        self.assertLess(errs[1], errs[0])

    def test_sampling_draws_match_execution_formula(self):
        """W uses one upper-triangle draw per symmetric entry, not m^2."""
        class CountingRNG:
            def __init__(self, seed=0):
                self.inner = np.random.default_rng(seed)
                self.draws = 0
            def choice(self, *args, **kwargs):
                return self.inner.choice(*args, **kwargs)
            def binomial(self, n, p, *args, **kwargs):
                self.draws += np.asarray(p).size
                return self.inner.binomial(n, p, *args, **kwargs)

        N, m, shots = 50, 12, 100
        X = np.random.default_rng(0).uniform(-1, 1, (N, 4))
        rng = CountingRNG()
        res = nystrom_sketch(quantum_kernel_fn(EncodingConfig(4)), X,
                             SketchConfig(m=m, shots=shots), rng)
        expected_entries = N * m + m * (m + 1) // 2
        self.assertEqual(rng.draws, expected_entries)
        self.assertEqual(res.executions, shots * expected_entries)

    def test_progressive_acquisition_reuses_existing_columns(self):
        X = np.random.default_rng(7).uniform(-1, 1, (30, 4))
        prog = ProgressiveNystrom(quantum_kernel_fn(EncodingConfig(4)), X,
                                  100, np.random.default_rng(8))
        self.assertEqual(prog.acquire([0, 1]), 2)
        self.assertEqual(prog.executions, 100 * 30 * 2)
        self.assertEqual(prog.acquire([1, 2]), 1)
        self.assertEqual(prog.executions, 100 * 30 * 3)
        self.assertGreaterEqual(np.linalg.eigvalsh(prog.gram()).min(), -1e-9)


class TestCriterion(unittest.TestCase):
    def test_certificate_fires_on_redundant_kernel(self):
        rng = np.random.default_rng(3)
        X = rng.uniform(-np.pi, np.pi, (60, 6))
        dic = build_dictionary()
        K_land = normalize_gram(product_kernel(X, X))
        cert = redundancy_certificate(K_land, [normalize_gram(fn(X)) for _, fn in dic])
        self.assertGreater(cert.r_squared, 0.9)

    def test_phi_positive_when_quantum_adds_alignment(self):
        rng = np.random.default_rng(4)
        from hqkm.datasets import make_synthetic
        X, y, _ = make_synthetic("S3_entangled_anchor", 120, 6, rng,
                                 EncodingConfig())
        qfn = quantum_kernel_fn(EncodingConfig())
        grams = [normalize_gram(fn(X)) for _, fn in build_dictionary()]
        K_c = sum(g / len(grams) for g in grams)
        K_h = K_c * 0.8 + normalize_gram(qfn(X)) * 0.2
        crit = benefit_criterion(K_c, K_h, y)
        self.assertIsInstance(crit.phi, float)

    def test_centered_solver_optimizes_centered_alignment(self):
        from hqkm.kernels import alignment, solve_mkl_alignment
        rng = np.random.default_rng(44)
        X = rng.normal(size=(80, 3))
        y = np.where(X[:, 0] > np.median(X[:, 0]), 1.0, -1.0)
        grams = [fn(X) for _, fn in build_dictionary()]
        beta = solve_mkl_alignment(grams, y, iters=80, centered=True)
        K = sum(b * normalize_gram(g) for b, g in zip(beta, grams))
        uniform = sum(normalize_gram(g) for g in grams) / len(grams)
        self.assertGreaterEqual(alignment(K, y, centered=True),
                                alignment(uniform, y, centered=True) - 1e-8)


class TestDatasets(unittest.TestCase):
    def test_synthetic_families_generate(self):
        for fam in ("S1_mixed", "S2_in_rkhs", "S3_entangled_anchor",
                    "S4_high_freq", "S5_noise"):
            X, y, spec = load_dataset(fam, 80, 6, seed=0)
            self.assertEqual(X.shape, (80, 6))
            self.assertTrue(set(np.unique(y)) <= {-1.0, 1.0})
            self.assertIsNotNone(spec.expected_benefit)

    def test_splits_are_stratified_and_disjoint(self):
        y = np.r_[np.ones(50), -np.ones(50)]
        tr, tu, te = make_splits(y, np.random.default_rng(0))
        self.assertEqual(len(tr) + len(tu) + len(te), 100)
        self.assertEqual(len(set(tr) | set(tu) | set(te)), 100)
        self.assertAlmostEqual((y[tr] > 0).mean(), 0.5, delta=0.05)

    def test_real_preprocessor_is_fit_on_training_rows_only(self):
        import hqkm.protocol as protocol
        observed = []
        original = protocol.fit_real_preprocessor
        def recorder(X, n_components):
            observed.append(len(X))
            return original(X, n_components)
        cfg = ProtocolConfig(seeds=(0,), n_samples=100, n_features=6,
                             models=("classical_mkl",))
        cfg.model_cfg.mkl_iters = 5
        with mock.patch.object(protocol, "fit_real_preprocessor", recorder):
            row = run_single("breast_cancer", "classical_mkl", 0, cfg)
        self.assertEqual(observed, [row["n_train"]])
        self.assertLess(row["n_train"], 100)

    def test_all_bundled_binary_tasks_load_with_both_classes(self):
        names = ("breast_cancer", "digits01", "digits17", "digits38",
                 "digits49", "digits56", "wine", "wine02", "wine12",
                 "iris01", "iris02", "iris12")
        for name in names:
            X, y, spec = load_dataset(name, n_samples=80, n_features=6,
                                      seed=0, preprocess=False)
            with self.subTest(name=name):
                self.assertEqual(spec.kind, "real")
                self.assertEqual(set(np.unique(y)), {-1.0, 1.0})
                self.assertEqual(len(X), len(y))

    def test_uploaded_loader_preserves_headerless_first_row_and_deduplicates(self):
        import tempfile
        from hqkm.local_datasets import UPLOAD_MANIFEST, load_uploaded_dataset
        with tempfile.TemporaryDirectory() as root:
            path = Path(root) / "tiny.csv"
            path.write_text("1,2,a\n3,4,b\n1,2,a\n", encoding="utf-8")
            spec = {"filename": "tiny.csv", "header": None, "target": -1,
                    "status": "accepted", "reason": "test"}
            with mock.patch.dict(UPLOAD_MANIFEST, {"tiny": spec}):
                X, y, audit = load_uploaded_dataset(root, "tiny")
            self.assertEqual(audit["original_rows"], 3)
            self.assertEqual(audit["usable_rows"], 2)
            self.assertEqual(X.shape, (2, 2))
            self.assertEqual(set(y), {-1.0, 1.0})

    def test_uploaded_loader_refuses_rejected_schema(self):
        from hqkm.local_datasets import load_uploaded_dataset
        with self.assertRaisesRegex(ValueError, "rejected"):
            load_uploaded_dataset("/does/not/matter", "miniboone")

    def test_uploaded_loader_supports_headerless_semicolon_data(self):
        import tempfile
        from hqkm.local_datasets import UPLOAD_MANIFEST, load_uploaded_dataset
        with tempfile.TemporaryDirectory() as root:
            path = Path(root) / "tiny_semicolon.csv"
            path.write_text("1;2;RB\n3;4;NRB\n", encoding="utf-8")
            spec = {"filename": path.name, "header": None, "sep": ";",
                    "target": -1, "status": "accepted", "reason": "test"}
            with mock.patch.dict(UPLOAD_MANIFEST, {"tiny_sc": spec}):
                X, y, audit = load_uploaded_dataset(root, "tiny_sc")
            self.assertEqual(audit["original_rows"], 2)
            self.assertEqual(X.shape, (2, 2))
            self.assertEqual(set(y), {-1.0, 1.0})

    def test_uploaded_loader_decodes_arff_nominals(self):
        import tempfile
        from hqkm.local_datasets import UPLOAD_MANIFEST, load_uploaded_dataset
        body = """@RELATION tiny
@ATTRIBUTE x NUMERIC
@ATTRIBUTE kind {a,b}
@ATTRIBUTE class {good,bad}
@DATA
1,a,good
2,b,bad
"""
        with tempfile.TemporaryDirectory() as root:
            path = Path(root) / "tiny.arff"
            path.write_text(body, encoding="utf-8")
            spec = {"filename": path.name, "format": "arff", "target": "class",
                    "status": "accepted", "reason": "test"}
            with mock.patch.dict(UPLOAD_MANIFEST, {"tiny_arff": spec}):
                X, y, audit = load_uploaded_dataset(root, "tiny_arff")
            self.assertEqual(audit["original_rows"], 2)
            self.assertEqual(set(y), {-1.0, 1.0})
            self.assertGreaterEqual(X.shape[1], 3)


class TestModels(unittest.TestCase):
    def test_every_model_runs_and_produces_valid_scores(self):
        X, y, _ = load_dataset("S3_entangled_anchor", 150, 6, seed=1)
        tr, tu, te = make_splits(y, np.random.default_rng(1))
        cfg = ModelConfig(mkl_iters=25, qnn_iters=10,
                          sketch=SketchConfig(m=30, shots=1000))
        for name in ALL_MODELS:
            with self.subTest(model=name):
                m = build_model(name, cfg, np.random.default_rng(2))
                m.fit(X[tr], y[tr], X[tu], y[tu])
                mt = classification_metrics(m.decision_function(X[te]), y[te])
                self.assertTrue(np.isfinite(mt.auc))
                self.assertTrue(0.0 <= mt.auc <= 1.0)
                self.assertIsInstance(m.executions, float)

    def test_quantum_and_hybrid_beat_classical_on_entangled_data(self):
        # S3's label lives in the quantum RKHS; this is the one setting where
        # the quantum kernel is *expected* to help, so the ordering
        # hybrid >= classical and quantum >= 0.55 must hold.
        X, y, _ = load_dataset("S3_entangled_anchor", 300, 6, seed=3)
        tr, tu, te = make_splits(y, np.random.default_rng(3))
        cfg = ModelConfig(mkl_iters=40, qnn_iters=10,
                          sketch=SketchConfig(m=60, shots=1000))
        aucs = {}
        for name in ("classical_mkl", "quantum_only", "hybrid_mkl"):
            m = build_model(name, cfg, np.random.default_rng(4))
            m.fit(X[tr], y[tr], X[tu], y[tu])
            aucs[name] = classification_metrics(m.decision_function(X[te]), y[te]).auc
        self.assertGreaterEqual(aucs["hybrid_mkl"], aucs["classical_mkl"] - 0.02)
        self.assertGreaterEqual(aucs["quantum_only"], 0.55)

    def test_finite_shots_change_quantum_predictions_and_are_counted(self):
        X, y, _ = load_dataset("S3_entangled_anchor", 90, 4, seed=9,
                               encoding=EncodingConfig(4))
        tr, tu, te = make_splits(y, np.random.default_rng(9))
        exact_cfg = ModelConfig(encoding=EncodingConfig(4),
                                sketch=SketchConfig(m=20, shots="exact"))
        noisy_cfg = ModelConfig(encoding=EncodingConfig(4),
                                sketch=SketchConfig(m=20, shots=50))
        exact = build_model("quantum_only", exact_cfg, np.random.default_rng(1))
        noisy = build_model("quantum_only", noisy_cfg, np.random.default_rng(1))
        exact.fit(X[tr], y[tr], X[tu], y[tu])
        noisy.fit(X[tr], y[tr], X[tu], y[tu])
        s_exact = exact.decision_function(X[te])
        s_noisy = noisy.decision_function(X[te])
        self.assertFalse(np.allclose(s_exact, s_noisy))
        expected = 50 * (len(tr) * (len(tr) + 1) / 2
                         + len(tu) * len(tr) + len(te) * len(tr))
        self.assertEqual(noisy.executions, expected)

    def test_budgeted_model_respects_budget_and_queries_test_only_after_fit(self):
        X, y, _ = load_dataset("S3_entangled_anchor", 120, 4, seed=10,
                               encoding=EncodingConfig(4))
        tr, tu, te = make_splits(y, np.random.default_rng(10))
        cfg = ModelConfig(
            mkl_iters=20, encoding=EncodingConfig(4),
            sketch=SketchConfig(m=20, shots=50),
            acquisition_rounds=(5, 10, 20), acquisition_patience=2,
            acquisition_cost_penalty=0.0)
        model = build_model("budgeted_hybrid_mkl", cfg, np.random.default_rng(11))
        model.fit(X[tr], y[tr], X[tu], y[tu])
        after_fit = model.executions
        acquired = model.info["acquired_landmarks"]
        self.assertEqual(after_fit, 50 * (len(tr) + len(tu)) * acquired)
        self.assertLessEqual(acquired, 20)
        model.decision_function(X[te])
        selected = model.info["selected_landmarks"]
        self.assertEqual(model.executions - after_fit, 50 * len(te) * selected)

    def test_budgeted_model_is_deterministic_and_charges_declined_exploration(self):
        X, y, _ = load_dataset("breast_cancer", 100, 4, seed=0,
                               preprocess=False)
        tr, tu, _ = make_splits(y, np.random.default_rng(0))
        cfg = ModelConfig(mkl_iters=10, encoding=EncodingConfig(4),
                          sketch=SketchConfig(m=10, shots=30),
                          acquisition_rounds=(5, 10), acquisition_patience=1,
                          acquisition_cost_penalty=100.0)
        infos = []
        for _ in range(2):
            model = build_model("budgeted_hybrid_mkl", cfg, np.random.default_rng(4))
            model.fit(X[tr], y[tr], X[tu], y[tu])
            infos.append(model.info)
            self.assertFalse(model.info["selected_quantum"])
            self.assertGreater(model.info["exploration_executions"], 0)
        self.assertEqual(infos[0]["acquisition_history"],
                         infos[1]["acquisition_history"])

    def test_budgeted_ablation_strategies_and_auc_metric_run(self):
        X, y, _ = load_dataset("S3_entangled_anchor", 80, 4, seed=12,
                               encoding=EncodingConfig(4))
        tr, tu, _ = make_splits(y, np.random.default_rng(12))
        for strategy in ("residual", "uncertainty", "random", "kmeans", "multiobjective"):
            cfg = ModelConfig(mkl_iters=5, encoding=EncodingConfig(4),
                              sketch=SketchConfig(m=10, shots=20),
                              acquisition_rounds=(5, 10), acquisition_patience=1,
                              acquisition_strategy=strategy,
                              acquisition_metric="auc",
                              acquisition_cost_penalty=0.0)
            with self.subTest(strategy=strategy):
                model = build_model("budgeted_hybrid_mkl", cfg,
                                    np.random.default_rng(13))
                model.fit(X[tr], y[tr], X[tu], y[tu])
                self.assertEqual(model.info["acquisition_metric"], "auc")
                self.assertEqual(model.info["acquisition_strategy"], strategy)
                self.assertTrue(np.isfinite(model.info["tune_auc"]))

    def test_multiobjective_acquisition_hard_budget_and_frozen_test_path(self):
        X, y, _ = load_dataset("S3_entangled_anchor", 120, 4, seed=21,
                               encoding=EncodingConfig(4))
        tr, tu, te = make_splits(y, np.random.default_rng(21))
        per_landmark = 25 * (len(tr) + len(tu))
        cfg = ModelConfig(
            mkl_iters=10, encoding=EncodingConfig(4),
            sketch=SketchConfig(m=20, shots=25),
            acquisition_rounds=(5, 10, 20),
            acquisition_strategy="multiobjective",
            acquisition_metric="multiobjective",
            acquisition_max_executions=10 * per_landmark,
            acquisition_cost_penalty=0.0, acquisition_patience=3)
        model = build_model("budgeted_hybrid_mkl", cfg, np.random.default_rng(22))
        model.fit(X[tr], y[tr], X[tu], y[tu])
        fit_cost = model.executions
        frozen = (model.info["selected_landmarks"],
                  [h["landmarks"] for h in model.info["acquisition_history"]])
        self.assertLessEqual(fit_cost, cfg.acquisition_max_executions)
        self.assertTrue(model.info["budget_exhausted"])
        self.assertEqual(model.info["acquired_landmarks"], 10)
        model.decision_function(X[te])
        self.assertEqual(frozen, (model.info["selected_landmarks"],
                                  [h["landmarks"] for h in model.info["acquisition_history"]]))
        self.assertEqual(model.executions - fit_cost,
                         25 * len(te) * model.info["selected_landmarks"])

    def test_multiobjective_weights_are_validated(self):
        X, y, _ = load_dataset("S3_entangled_anchor", 60, 4, seed=23,
                               encoding=EncodingConfig(4))
        tr, tu, _ = make_splits(y, np.random.default_rng(23))
        cfg = ModelConfig(
            encoding=EncodingConfig(4), sketch=SketchConfig(m=5, shots=10),
            acquisition_rounds=(5,), acquisition_strategy="multiobjective",
            acquisition_residual_weight=.8,
            acquisition_uncertainty_weight=.3,
            acquisition_diversity_weight=.2)
        with self.assertRaisesRegex(ValueError, "sum to one"):
            build_model("budgeted_hybrid_mkl", cfg, np.random.default_rng(24)).fit(
                X[tr], y[tr], X[tu], y[tu])


class TestMetrics(unittest.TestCase):
    def test_auc_perfect_and_chance(self):
        y = np.r_[np.ones(10), -np.ones(10)]
        self.assertAlmostEqual(classification_metrics(np.r_[np.linspace(1, 2, 10),
                                                            np.linspace(-2, -1, 10)], y).auc, 1.0)
        # all-tied scores give exactly 0.5 (note: scores == y is perfect, not chance)
        self.assertAlmostEqual(classification_metrics(np.zeros(20), y).auc, 0.5)

    def test_holm_monotone(self):
        out = __import__("hqkm").holm_bonferroni({"a": 0.01, "b": 0.04, "c": 0.03})
        self.assertTrue(out["a"]["significant"])
        self.assertGreaterEqual(out["b"]["p_adjusted"], out["c"]["p_adjusted"] - 1e-12)

    def test_small_sample_tests_match_exact_reference(self):
        d = np.array([0.175, 0.24, 0.23, 0.145, 0.15])
        _, p_w = wilcoxon_signed_rank(d)
        _, p_t = paired_t_test(d)
        self.assertAlmostEqual(p_w, 0.0625)
        self.assertAlmostEqual(p_t, 0.0007017855843797237)


class TestMetaGate(unittest.TestCase):
    def test_gate_uses_only_allowlisted_finite_meta_features(self):
        from hqkm.meta_gate import ClassicalPreAcquisitionGate, META_FEATURES
        rows = [{name: float(i + j + 1) for j, name in enumerate(META_FEATURES)}
                for i in range(4)]
        for row in rows:
            row["forbidden_test_accuracy"] = 999.0
        gate = ClassicalPreAcquisitionGate().fit(rows, [-1., 0., 1., 2.])
        before = gate.predict_value(rows)
        for row in rows:
            row["forbidden_test_accuracy"] = -999.0
        np.testing.assert_allclose(before, gate.predict_value(rows))

    def test_gate_rejects_nonfinite_or_incomplete_rows(self):
        from hqkm.meta_gate import ClassicalPreAcquisitionGate, META_FEATURES
        valid = {name: 1.0 for name in META_FEATURES}
        bad = valid.copy(); bad[META_FEATURES[0]] = np.nan
        with self.assertRaisesRegex(ValueError, "finite"):
            ClassicalPreAcquisitionGate().fit([valid, bad], [0., 1.])
        incomplete = valid.copy(); incomplete.pop(META_FEATURES[-1])
        with self.assertRaises(KeyError):
            ClassicalPreAcquisitionGate().fit([valid, incomplete], [0., 1.])


class TestUtilityGate(unittest.TestCase):
    def test_score_uses_only_tune_gain_cost_and_eta(self):
        score = utility_score([0.05, 0.01], [1.0, 0.5], eta=0.02)
        self.assertTrue(np.allclose(score, [0.03, 0.0]))

    def test_eta_is_selected_only_from_supplied_calibration_rows(self):
        rows = [
            {"delta_tune_accuracy": .10, "delta_accuracy": .08,
             "normalized_quantum_cost": 1.0},
            {"delta_tune_accuracy": .01, "delta_accuracy": -.03,
             "normalized_quantum_cost": 1.0},
        ]
        eta, table = select_eta(rows, [0.0, 0.02, 0.05])
        self.assertEqual(eta, 0.02)
        result = evaluate_gate(rows, eta)
        self.assertEqual((result["tp"], result["fp"]), (1, 0))
        self.assertEqual(len(table), 3)


class TestLoodo(unittest.TestCase):
    def test_pareto_front_removes_dominated_points(self):
        from run_loodo import pareto_front
        points = [
            {"name": "base", "mean_executions": 0,
             "mean_delivered_accuracy_gain": 0},
            {"name": "bad", "mean_executions": 10,
             "mean_delivered_accuracy_gain": -0.1},
            {"name": "good", "mean_executions": 10,
             "mean_delivered_accuracy_gain": 0.1},
            {"name": "costly", "mean_executions": 20,
             "mean_delivered_accuracy_gain": 0.1},
        ]
        self.assertEqual([p["name"] for p in pareto_front(points)],
                         ["base", "good"])


if __name__ == "__main__":
    unittest.main()
