#!/usr/bin/env python3
"""Create a deterministic SHA-256 manifest for the public release tree."""
from __future__ import annotations

import hashlib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "SHA256SUMS"
EXCLUDED_PARTS = {".git", ".pytest_cache", "__pycache__", "build", "dist"}


def included(path: Path) -> bool:
    relative = path.relative_to(ROOT)
    return path != OUTPUT and not any(part in EXCLUDED_PARTS for part in relative.parts)


lines = []
for path in sorted(p for p in ROOT.rglob("*") if p.is_file() and included(p)):
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    lines.append(f"{digest}  {path.relative_to(ROOT).as_posix()}")

OUTPUT.write_text("\n".join(lines) + "\n", encoding="utf-8")
print(f"Wrote {OUTPUT.name} with {len(lines)} entries.")
