#!/usr/bin/env python3
"""Fail closed before a GitHub/Zenodo release is tagged."""
from __future__ import annotations

import json
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REQUIRED = [
    "README.md", "LICENSE", "CITATION.cff", ".zenodo.json",
    "pyproject.toml", "requirements.txt", "environment.yml",
    "REPRODUCIBILITY.md", "DATA.md", "CHANGELOG.md",
    "AUTHOR_METADATA_TEMPLATE.md", "RELEASE_NOTES_v1.0.0.md",
]
TEXT_FILES = [
    "README.md", "CITATION.cff", ".zenodo.json", "pyproject.toml",
    "REPRODUCIBILITY.md", "DATA.md", "CHANGELOG.md",
]


def fail(message: str) -> None:
    print(f"ERROR: {message}", file=sys.stderr)
    raise SystemExit(1)


missing = [name for name in REQUIRED if not (ROOT / name).is_file()]
if missing:
    fail(f"missing release files: {', '.join(missing)}")

for name in TEXT_FILES:
    text = (ROOT / name).read_text(encoding="utf-8")
    if re.search(r"REPLACE_WITH_[A-Z][A-Z0-9_]+", text):
        fail(f"unresolved publication metadata in {name}")
    if re.search(r"/workspace/|/home/[^ /]+|[A-Za-z]:\\\\Users\\\\", text):
        fail(f"local absolute path leaked into {name}")

json.loads((ROOT / ".zenodo.json").read_text(encoding="utf-8"))

tracked_results = list((ROOT / "results").glob("*.json"))
for path in tracked_results:
    text = path.read_text(encoding="utf-8")
    if re.search(r"/workspace/|/home/[^ /]+|[A-Za-z]:\\\\Users\\\\", text):
        fail(f"local path leaked into result artifact {path.relative_to(ROOT)}")

subprocess.run([sys.executable, "-m", "pytest", "-q"], cwd=ROOT, check=True)
print("Release check passed: metadata resolved, JSON valid, no local paths, tests green.")
