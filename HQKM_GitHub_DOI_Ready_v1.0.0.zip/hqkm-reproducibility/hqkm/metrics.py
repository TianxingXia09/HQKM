"""Metrics and statistical protocol.

Everything here is implemented on numpy so the package runs without scipy. The
significance machinery matters as much as the point estimates: the design
requires paired tests on identical splits, effect sizes, and confidence
intervals, and forbids reporting aggregate numbers only.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, asdict

import numpy as np

__all__ = [
    "ClassificationMetrics",
    "classification_metrics",
    "roc_curve",
    "auc_score",
    "spearman_rho",
    "paired_bootstrap_ci",
    "wilcoxon_signed_rank",
    "paired_t_test",
    "holm_bonferroni",
    "cohens_d",
]


@dataclass
class ClassificationMetrics:
    accuracy: float
    balanced_accuracy: float
    precision: float
    recall: float
    f1: float
    auc: float
    tp: int
    fp: int
    fn: int
    tn: int

    def as_dict(self) -> dict:
        return asdict(self)


def classification_metrics(scores: np.ndarray, y_true: np.ndarray) -> ClassificationMetrics:
    """Full metric set from real-valued scores and ``{-1,+1}`` labels."""
    pred = np.where(scores >= 0.0, 1.0, -1.0)
    tp = int(((pred > 0) & (y_true > 0)).sum())
    fp = int(((pred > 0) & (y_true <= 0)).sum())
    fn = int(((pred <= 0) & (y_true > 0)).sum())
    tn = int(((pred <= 0) & (y_true <= 0)).sum())
    acc = (tp + tn) / max(tp + fp + fn + tn, 1)
    tpr = tp / max(tp + fn, 1)
    tnr = tn / max(tn + fp, 1)
    prec = tp / max(tp + fp, 1)
    f1 = 2 * prec * tpr / max(prec + tpr, 1e-12)
    return ClassificationMetrics(
        accuracy=float(acc), balanced_accuracy=float(0.5 * (tpr + tnr)),
        precision=float(prec), recall=float(tpr), f1=float(f1),
        auc=float(auc_score(scores, y_true)), tp=tp, fp=fp, fn=fn, tn=tn,
    )


def roc_curve(scores: np.ndarray, y_true: np.ndarray):
    """Return ``(fpr, tpr)`` arrays, sorted by decreasing score."""
    order = np.argsort(-scores)
    pos = (y_true[order] > 0).astype(float)
    tps = np.cumsum(pos)
    fps = np.cumsum(1.0 - pos)
    n_pos, n_neg = max(pos.sum(), 1.0), max(len(pos) - pos.sum(), 1.0)
    return np.r_[0.0, fps / n_neg], np.r_[0.0, tps / n_pos]


def auc_score(scores: np.ndarray, y_true: np.ndarray) -> float:
    """ROC AUC via the rank (Mann-Whitney) identity, ties averaged."""
    pos = scores[y_true > 0]
    neg = scores[y_true <= 0]
    if len(pos) == 0 or len(neg) == 0:
        return float("nan")
    order = np.argsort(np.r_[pos, neg])
    ranks = np.empty(len(order), dtype=float)
    ranks[order] = np.arange(1, len(order) + 1)
    # average ranks within ties
    allv = np.r_[pos, neg]
    for value in np.unique(allv):
        mask = allv == value
        if mask.sum() > 1:
            ranks[mask] = ranks[mask].mean()
    r_pos = ranks[: len(pos)].sum()
    return float((r_pos - len(pos) * (len(pos) + 1) / 2.0) / (len(pos) * len(neg)))


def spearman_rho(a: np.ndarray, b: np.ndarray) -> float:
    """Spearman rank correlation with tie-averaged ranks."""
    def _rank(v):
        order = np.argsort(v)
        r = np.empty(len(v), dtype=float)
        r[order] = np.arange(1, len(v) + 1)
        for value in np.unique(v):
            mask = v == value
            if mask.sum() > 1:
                r[mask] = r[mask].mean()
        return r
    ra, rb = _rank(np.asarray(a, float)), _rank(np.asarray(b, float))
    ra, rb = ra - ra.mean(), rb - rb.mean()
    denom = math.sqrt(float((ra ** 2).sum() * (rb ** 2).sum()))
    return float(ra @ rb / max(denom, 1e-12))


def paired_bootstrap_ci(diff: np.ndarray, n_boot: int = 10000,
                        alpha: float = 0.05, seed: int = 0):
    """Percentile bootstrap CI for the mean of paired differences."""
    rng = np.random.default_rng(seed)
    diff = np.asarray(diff, float)
    means = diff[rng.integers(0, len(diff), (n_boot, len(diff)))].mean(1)
    lo, hi = np.quantile(means, [alpha / 2.0, 1.0 - alpha / 2.0])
    return float(diff.mean()), float(lo), float(hi)


def wilcoxon_signed_rank(diff: np.ndarray) -> tuple[float, float]:
    """Two-sided Wilcoxon signed-rank test with tie/zero handling."""
    d = np.asarray(diff, float)
    d = d[d != 0]
    n = len(d)
    if n == 0:
        return 0.0, 1.0
    from scipy import stats
    result = stats.wilcoxon(d, alternative="two-sided", method="auto")
    return float(result.statistic), float(result.pvalue)


def paired_t_test(diff: np.ndarray) -> tuple[float, float]:
    """Two-sided one-sample t-test on paired differences."""
    d = np.asarray(diff, float)
    n = len(d)
    if n < 2:
        return 0.0, 1.0
    if np.allclose(d, d[0]):
        return (0.0, 1.0) if np.isclose(d[0], 0.0) else (
            math.copysign(float("inf"), d[0]), 0.0)
    from scipy import stats
    result = stats.ttest_1samp(d, popmean=0.0)
    return float(result.statistic), float(result.pvalue)


def cohens_d(diff: np.ndarray) -> float:
    """Effect size for paired differences."""
    d = np.asarray(diff, float)
    return float(d.mean() / max(d.std(ddof=1), 1e-12))


def holm_bonferroni(pvalues: dict[str, float], alpha: float = 0.05) -> dict[str, dict]:
    """Holm-Bonferroni correction across a family of comparisons."""
    items = sorted(pvalues.items(), key=lambda kv: kv[1])
    m = len(items)
    out: dict[str, dict] = {}
    prev = 0.0
    for i, (key, p) in enumerate(items):
        adj = min(1.0, max(prev, (m - i) * p))
        prev = adj
        out[key] = dict(p_raw=float(p), p_adjusted=float(adj),
                        significant=bool(adj <= alpha))
    return out
