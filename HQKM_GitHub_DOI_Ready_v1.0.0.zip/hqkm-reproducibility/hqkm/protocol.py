"""Experimental protocol: the five studies, with the statistics the design requires.

Every study obeys the same rules. Splits are stratified train/tune/test, drawn
once per seed; the tuning split sets ``lambda``, ``m``, ``s`` and never the
criterion threshold; the test split is touched once. Comparisons are paired on
identical splits, and families of comparisons are corrected with
Holm-Bonferroni. Per-dataset results are always retained -- aggregates are a
summary of them, never a substitute.

Studies
-------
``run_criterion_study``
    Does the criterion predict realized benefit? Rank correlation between
    ``Phi`` and the accuracy delta, plus the confusion matrix of the decision.
``run_estimator_study``
    How accurate is the sketch as a function of ``(m, s)``, and does the
    spectral summary drift?
``run_scaling_study``
    Circuit executions and wall-clock as a function of ``N``.
``run_benchmark_study``
    All models on all requested datasets, with paired significance tests.
``run_gate_study``
    Does the redundancy certificate decline the quantum kernel before paying for
    the full Gram, and is it ever wrong?
"""

from __future__ import annotations

import json
import time
import tracemalloc
from dataclasses import dataclass, field, asdict

import numpy as np

from .baselines import ModelConfig, build_model
from .criterion import benefit_criterion, redundancy_certificate
from .datasets import (fit_real_preprocessor, load_dataset, make_splits,
                       transform_real_features)
from .estimator import (SketchConfig, executions_exact, executions_sketch,
                        nystrom_sketch)
from .kernels import (alignment, build_dictionary, effective_dimension,
                      normalize_gram, solve_mkl_alignment)
from .metrics import (classification_metrics, cohens_d, holm_bonferroni,
                      paired_bootstrap_ci, paired_t_test, spearman_rho,
                      wilcoxon_signed_rank)
from .quantum import EncodingConfig, quantum_kernel_fn

__all__ = [
    "ProtocolConfig",
    "run_single",
    "run_criterion_study",
    "run_estimator_study",
    "run_scaling_study",
    "run_benchmark_study",
    "run_gate_study",
    "run_all",
]

DEFAULT_MODELS = (
    "classical_single",
    "classical_mkl",
    "quantum_only",
    "quantum_aligned",
    "qnn",
    "emulator_prior_art",
    "hybrid_mkl",
)


@dataclass
class ProtocolConfig:
    """Everything that defines a reproducible run."""

    seeds: tuple[int, ...] = (0, 1, 2, 3, 4)
    n_samples: int = 1000
    n_features: int = 6
    datasets: tuple[str, ...] = ("S1_mixed", "S2_in_rkhs", "S3_entangled_anchor",
                                 "S4_high_freq", "S5_noise", "breast_cancer")
    models: tuple[str, ...] = DEFAULT_MODELS
    mixing_grid: tuple[float, ...] = (0.0, 0.25, 0.5, 0.75, 1.0)
    noise_grid: tuple[float, ...] = (0.0, 0.1)
    m_grid: tuple[int, ...] = (100, 200, 400)
    shots_grid: tuple = (200, 1000, "exact")
    scaling_sizes: tuple[int, ...] = (500, 1000, 2000)
    tau_phi: float = 0.0
    tau_certificate: float = 0.99
    alpha: float = 0.05
    model_cfg: ModelConfig = field(default_factory=ModelConfig)
    use_sketch: bool = False

    def as_dict(self) -> dict:
        d = asdict(self)
        d["shots_grid"] = [str(s) for s in self.shots_grid]
        return d


# --------------------------------------------------------------------------- #
# One (dataset, seed, model) cell
# --------------------------------------------------------------------------- #
def run_single(dataset: str, model_name: str, seed: int, cfg: ProtocolConfig,
               mixing: float = 0.5, noise_rate: float = 0.0) -> dict:
    """Fit one model on one split and return metrics, cost, and diagnostics."""
    encoding = cfg.model_cfg.encoding
    X, y, spec = load_dataset(dataset, cfg.n_samples, cfg.n_features, seed,
                             encoding, mixing, noise_rate,
                             preprocess=False)
    rng = np.random.default_rng(seed)
    tr, tu, te = make_splits(y, rng)
    if spec.kind == "real":
        prep = fit_real_preprocessor(X[tr], cfg.n_features)
        X_processed = np.empty((len(X), cfg.n_features), dtype=float)
        X_processed[tr] = transform_real_features(X[tr], prep)
        X_processed[tu] = transform_real_features(X[tu], prep)
        X_processed[te] = transform_real_features(X[te], prep)
        X = X_processed
    model = build_model(model_name, cfg.model_cfg, np.random.default_rng(seed + 7919))
    tracemalloc.start()
    t0 = time.perf_counter()
    model.fit(X[tr], y[tr], X[tu], y[tu])
    scores = model.decision_function(X[te])
    wall = time.perf_counter() - t0
    _, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    metrics = classification_metrics(scores, y[te])
    return dict(dataset=dataset, model=model_name, seed=seed, mixing=mixing,
                noise_rate=noise_rate, n_train=len(tr), n_tune=len(tu),
                n_test=len(te),
                executions=model.executions, wall_clock_s=wall,
                peak_memory_mb=peak / 2 ** 20, info=model.info,
                expected_benefit=spec.expected_benefit, **metrics.as_dict())


# --------------------------------------------------------------------------- #
# E1: criterion validity
# --------------------------------------------------------------------------- #
def run_criterion_study(cfg: ProtocolConfig) -> dict:
    """Paired hybrid-vs-classical runs; does ``Phi - tau`` predict the sign of the gain?

    Sweeps the mixing parameter and the noise rate, which is the only setting in
    which the effective dimension of the quantum component can be varied
    independently of everything else.
    """
    rows: list[dict] = []
    families = ("S1_mixed", "S2_in_rkhs", "S3_entangled_anchor", "S4_high_freq",
                "S5_noise")
    for family in families:
        grid = cfg.mixing_grid if family == "S1_mixed" else (0.5,)
        for mixing in grid:
            for noise in cfg.noise_grid:
                for seed in cfg.seeds:
                    hyb = run_single(family, "hybrid_mkl", seed, cfg, mixing, noise)
                    cls = run_single(family, "classical_mkl", seed, cfg, mixing, noise)
                    phi = float(hyb["info"].get("phi", float("nan")))
                    shots = (1 if cfg.model_cfg.sketch.shots == "exact"
                             else int(cfg.model_cfg.sketch.shots))
                    reference_cost = shots * (
                        hyb["n_train"] * (hyb["n_train"] + 1) / 2
                        + hyb["n_tune"] * hyb["n_train"]
                        + hyb["n_test"] * hyb["n_train"])
                    rows.append(dict(
                        family=family, mixing=mixing, noise_rate=noise, seed=seed,
                        phi=phi, predicted=bool(phi > cfg.tau_phi),
                        delta_accuracy=hyb["accuracy"] - cls["accuracy"],
                        delta_tune_accuracy=float(
                            hyb["info"].get("tune_accuracy", np.nan)
                            - cls["info"].get("tune_accuracy", np.nan)),
                        quantum_executions=float(hyb["executions"]),
                        normalized_quantum_cost=float(
                            hyb["executions"] / max(reference_cost, 1.0)),
                        delta_auc=hyb["auc"] - cls["auc"],
                        delta_alignment=float(hyb["info"].get("delta_alignment", np.nan)),
                        bound_gap=float(hyb["info"].get("bound_gap", np.nan)),
                        beta_quantum=float(hyb["info"].get("beta_quantum", 0.0)),
                        floor_active=bool(hyb["info"].get("phi_floor_active", False)),
                        expected_benefit=hyb["expected_benefit"],
                    ))
    phi = np.array([r["phi"] for r in rows])
    dacc = np.array([r["delta_accuracy"] for r in rows])
    ok = np.isfinite(phi) & np.isfinite(dacc)
    pred = phi[ok] > cfg.tau_phi
    truth = dacc[ok] > 0.0
    tp = int((pred & truth).sum())
    fp = int((pred & ~truth).sum())
    fn = int((~pred & truth).sum())
    tn = int((~pred & ~truth).sum())
    mean, lo, hi = paired_bootstrap_ci(dacc[ok])
    _, p_w = wilcoxon_signed_rank(dacc[ok])
    return dict(
        rows=rows,
        spearman_phi_delta_accuracy=spearman_rho(phi[ok], dacc[ok]),
        spearman_alignment_delta_accuracy=spearman_rho(
            np.array([r["delta_alignment"] for r in rows])[ok], dacc[ok]),
        spearman_bound_gap_delta_accuracy=spearman_rho(
            np.array([r["bound_gap"] for r in rows])[ok], dacc[ok]),
        confusion=dict(tp=tp, fp=fp, fn=fn, tn=tn),
        decision_accuracy=(tp + tn) / max(tp + fp + fn + tn, 1),
        false_negative_rate=fn / max(tp + fn, 1),
        mean_delta_accuracy=mean, ci_low=lo, ci_high=hi,
        wilcoxon_p=p_w, cohens_d=cohens_d(dacc[ok]),
        tau_phi=cfg.tau_phi,
        caveat="tau=0 is a pilot proxy; the analytic threshold is an open item",
    )


# --------------------------------------------------------------------------- #
# E2: estimator quality
# --------------------------------------------------------------------------- #
def run_estimator_study(cfg: ProtocolConfig) -> dict:
    """Relative Frobenius error and spectral drift over the ``(m, s)`` grid.

    Drift is reported one-sided as well as two-sided, because a systematically
    *downward* drift indicates Nystrom truncation bias rather than shot noise,
    and the two have different consequences for the criterion.
    """
    rows: list[dict] = []
    encoding = cfg.model_cfg.encoding
    qfn = quantum_kernel_fn(encoding)
    for seed in cfg.seeds:
        X, y, _ = load_dataset("S3_entangled_anchor", cfg.n_samples,
                               cfg.n_features, seed, encoding)
        K_true = normalize_gram(qfn(X))
        d_true = effective_dimension(K_true, cfg.model_cfg.lam_deff)
        a_true = alignment(K_true, y)
        for m in cfg.m_grid:
            for shots in cfg.shots_grid:
                rng = np.random.default_rng(seed * 1000 + m)
                sk = SketchConfig(m=m, shots=shots,
                                  tau_coefficient=cfg.model_cfg.sketch.tau_coefficient,
                                  psd_repair=cfg.model_cfg.sketch.psd_repair)
                res = nystrom_sketch(qfn, X, sk, rng)
                K_hat = normalize_gram(res.gram)
                d_hat = effective_dimension(K_hat, cfg.model_cfg.lam_deff)
                rows.append(dict(
                    seed=seed, m=m, shots=str(shots),
                    eps_frobenius=float(np.linalg.norm(K_hat - K_true)
                                        / max(np.linalg.norm(K_true), 1e-12)),
                    d_eff_true=d_true, d_eff_hat=d_hat,
                    drift=float(abs(d_hat - d_true) / max(d_true, 1e-12)),
                    signed_drift=float((d_hat - d_true) / max(d_true, 1e-12)),
                    alignment_error=float(abs(alignment(K_hat, y) - a_true)),
                    rank=res.rank, tau_trunc=res.tau_trunc,
                    negative_mass=res.negative_mass,
                    min_eigenvalue=res.min_eigenvalue,
                    executions=res.executions,
                    executions_exact=executions_exact(
                        len(X), 1 if shots == "exact" else int(shots)),
                ))
    return dict(rows=rows,
                note="psd_repair measured as a no-op in this regime is a finding, "
                     "not an omission; report negative_mass to substantiate it")


# --------------------------------------------------------------------------- #
# E3: cost scaling
# --------------------------------------------------------------------------- #
def run_scaling_study(cfg: ProtocolConfig) -> dict:
    """Executions saved by sketching, plus measured wall-clock, versus ``N``."""
    rows: list[dict] = []
    encoding = cfg.model_cfg.encoding
    qfn = quantum_kernel_fn(encoding)
    shots = 1000
    for N in cfg.scaling_sizes:
        for m in cfg.m_grid:
            if m >= N:
                continue
            X, _, _ = load_dataset("S3_entangled_anchor", N, cfg.n_features, 0, encoding)
            rng = np.random.default_rng(0)
            t0 = time.perf_counter()
            res = nystrom_sketch(qfn, X, SketchConfig(m=m, shots=shots), rng)
            wall = time.perf_counter() - t0
            exact = executions_exact(N, shots)
            rows.append(dict(N=N, m=m, shots=shots, executions_sketch=res.executions,
                             executions_exact=exact,
                             reduction_factor=exact / max(res.executions, 1.0),
                             wall_clock_s=wall, rank=res.rank))
    return dict(rows=rows,
                formula=dict(sketch="s*(N*m + m(m+1)/2)", exact="s*N(N+1)/2"),
                note="the reduction factor is analytic in (N, m, s); wall-clock is "
                     "simulator-specific and reported only for transparency")


# --------------------------------------------------------------------------- #
# E4: full benchmark with paired tests
# --------------------------------------------------------------------------- #
def run_benchmark_study(cfg: ProtocolConfig) -> dict:
    """All models on all datasets, paired per seed, Holm-corrected per dataset."""
    rows: list[dict] = []
    for dataset in cfg.datasets:
        for model in cfg.models:
            for seed in cfg.seeds:
                try:
                    rows.append(run_single(dataset, model, seed, cfg))
                except Exception as exc:  # keep going; record the failure honestly
                    rows.append(dict(dataset=dataset, model=model, seed=seed,
                                     error=f"{type(exc).__name__}: {exc}"))

    per_dataset: dict[str, dict] = {}
    for dataset in cfg.datasets:
        pvals: dict[str, float] = {}
        detail: dict[str, dict] = {}
        ours = _series(rows, dataset, "hybrid_mkl", "accuracy")
        for model in cfg.models:
            if model == "hybrid_mkl":
                continue
            other = _series(rows, dataset, model, "accuracy")
            if len(ours) != len(other) or len(ours) < 2:
                continue
            diff = ours - other
            mean, lo, hi = paired_bootstrap_ci(diff)
            _, p_w = wilcoxon_signed_rank(diff)
            _, p_t = paired_t_test(diff)
            pvals[model] = min(p_w, 1.0)
            detail[model] = dict(mean_delta_accuracy=mean, ci_low=lo, ci_high=hi,
                                 wilcoxon_p=p_w, t_test_p=p_t,
                                 cohens_d=cohens_d(diff))
        corrected = holm_bonferroni(pvals, cfg.alpha) if pvals else {}
        for model, stats in corrected.items():
            detail[model].update(stats)
        per_dataset[dataset] = dict(
            comparisons=detail,
            summary={model: dict(
                accuracy_mean=float(np.mean(_series(rows, dataset, model, "accuracy")))
                if len(_series(rows, dataset, model, "accuracy")) else None,
                accuracy_std=float(np.std(_series(rows, dataset, model, "accuracy")))
                if len(_series(rows, dataset, model, "accuracy")) else None,
                auc_mean=float(np.mean(_series(rows, dataset, model, "auc")))
                if len(_series(rows, dataset, model, "auc")) else None,
                executions_mean=float(np.mean(_series(rows, dataset, model, "executions")))
                if len(_series(rows, dataset, model, "executions")) else None,
            ) for model in cfg.models},
        )
    return dict(rows=rows, per_dataset=per_dataset,
                note="per-dataset results are primary; no aggregate-only claim")


def _series(rows: list[dict], dataset: str, model: str, key: str) -> np.ndarray:
    vals = [r[key] for r in rows
            if r.get("dataset") == dataset and r.get("model") == model and key in r]
    return np.asarray(vals, dtype=float)


# --------------------------------------------------------------------------- #
# E5: the decision gate
# --------------------------------------------------------------------------- #
def run_gate_study(cfg: ProtocolConfig) -> dict:
    """Does the redundancy certificate decline emulable quantum kernels cheaply?

    The certificate is computed from the landmark block alone, so the executions
    spent when it fires are ``s * m(m+1)/2`` rather than ``s * N(N+1)/2``. A
    firing that turns out to be wrong (the quantum kernel would have helped) is
    recorded as an error of the gate, not smoothed over.
    """
    rows: list[dict] = []
    shots = 1000
    for dataset in ("S2_in_rkhs", "S3_entangled_anchor", "S4_high_freq", "S5_noise"):
        for seed in cfg.seeds:
            for scale in (0.05, 0.25, 1.0, 2.0):
                encoding = EncodingConfig(cfg.model_cfg.encoding.n_qubits, scale,
                                          cfg.model_cfg.encoding.family,
                                          cfg.model_cfg.encoding.layers)
                X, y, _ = load_dataset(dataset, cfg.n_samples, cfg.n_features,
                                       seed, encoding)
                rng = np.random.default_rng(seed)
                m = min(cfg.m_grid[0], len(X) // 2)
                land = rng.choice(len(X), size=m, replace=False)
                qfn = quantum_kernel_fn(encoding)
                Kq_land = qfn(X[land], X[land])
                cls_land = [fn(X[land], X[land]) for _, fn in build_dictionary()]
                spent = executions_sketch(0, m, shots)
                cert = redundancy_certificate(Kq_land, cls_land,
                                              cfg.tau_certificate, spent)
                grams = [normalize_gram(fn(X)) for _, fn in build_dictionary()]
                beta_c = solve_mkl_alignment(grams, y, cfg.model_cfg.mkl_iters,
                                             cfg.model_cfg.mkl_lr,
                                             centered=cfg.model_cfg.centered_alignment)
                K_c = sum(b * g for b, g in zip(beta_c, grams))
                grams_q = grams + [normalize_gram(qfn(X))]
                beta_h = solve_mkl_alignment(grams_q, y, cfg.model_cfg.mkl_iters,
                                             cfg.model_cfg.mkl_lr,
                                             centered=cfg.model_cfg.centered_alignment)
                K_h = sum(b * g for b, g in zip(beta_h, grams_q))
                crit = benefit_criterion(K_c, K_h, y, cfg.model_cfg.lam_deff,
                                         cfg.model_cfg.centered_alignment)
                rows.append(dict(
                    dataset=dataset, seed=seed, encoding_scale=scale,
                    r_squared=cert.r_squared, fires=cert.fires,
                    executions_if_fired=spent,
                    executions_full=executions_exact(len(X), shots),
                    phi=crit.phi, beta_quantum=float(beta_h[-1]),
                    gate_error=bool(cert.fires and crit.phi > cfg.tau_phi),
                ))
    fired = np.array([r["fires"] for r in rows])
    errors = np.array([r["gate_error"] for r in rows])
    saved = np.array([r["executions_full"] - r["executions_if_fired"] for r in rows])
    return dict(rows=rows, fire_rate=float(fired.mean()) if len(fired) else 0.0,
                gate_error_rate=float(errors.mean()) if len(errors) else 0.0,
                mean_executions_saved_when_fired=float(saved[fired].mean())
                if fired.any() else 0.0,
                threshold=cfg.tau_certificate)


# --------------------------------------------------------------------------- #
# Driver
# --------------------------------------------------------------------------- #
def run_all(cfg: ProtocolConfig, studies: tuple[str, ...] = ("E1", "E2", "E3", "E4", "E5"),
            out_path: str | None = None) -> dict:
    """Run the requested studies and optionally write a JSON record."""
    runners = {"E1": run_criterion_study, "E2": run_estimator_study,
               "E3": run_scaling_study, "E4": run_benchmark_study,
               "E5": run_gate_study}
    out: dict = dict(config=cfg.as_dict(), studies={})
    t0 = time.perf_counter()
    for key in studies:
        if key not in runners:
            raise ValueError(f"unknown study {key!r}; available: {sorted(runners)}")
        started = time.perf_counter()
        out["studies"][key] = runners[key](cfg)
        out["studies"][key]["wall_clock_s"] = time.perf_counter() - started
    out["total_wall_clock_s"] = time.perf_counter() - t0
    if out_path:
        with open(out_path, "w", encoding="utf-8") as fh:
            json.dump(out, fh, indent=2, default=_json_default)
    return out


def _json_default(obj):
    if isinstance(obj, (np.floating, np.integer)):
        return obj.item()
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    if isinstance(obj, (np.bool_,)):
        return bool(obj)
    return str(obj)
