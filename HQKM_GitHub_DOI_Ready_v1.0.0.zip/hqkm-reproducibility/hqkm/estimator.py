"""Low-rank Gram estimation: Nystrom sketch, shot noise, noise-aware
truncation, PSD repair, and exact circuit-execution accounting.

The pilot studies identified the truncation rule as the load-bearing step: the
pseudo-inverse of the landmark block amplifies shot noise catastrophically
unless small eigenvalues are discarded, and the threshold that works scales as
``sqrt(m / (4 s))`` -- the typical size of a binomial perturbation eigenvalue.
With that rule in place, PSD repair is a measured no-op safety net rather than a
load-bearing correction, which is itself a reportable finding.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np

from .quantum import apply_shot_noise

__all__ = [
    "SketchConfig",
    "SketchResult",
    "select_landmarks",
    "nystrom_sketch",
    "executions_exact",
    "executions_sketch",
    "psd_repair",
    "ProgressiveNystrom",
]


@dataclass
class SketchConfig:
    """Estimator hyperparameters.

    Parameters
    ----------
    m:
        Number of landmark columns.
    shots:
        Shots per kernel entry, or ``"exact"``.
    landmark_rule:
        ``"uniform"`` (the analyzed default) or ``"kmeans"``. The k-means rule is
        included because the closest prior art uses it; it is a baseline
        mechanism, not our proposal.
    tau_coefficient:
        Multiplier ``tau_c`` in the truncation threshold
        ``tau_trunc = tau_c * sqrt(m / (4 s))``.
    psd_repair:
        Whether to clip negative eigenvalues of the sketched Gram. Disable to
        reproduce the prior-art-style pipeline that omits this step.
    """

    m: int = 200
    shots: int | str = 1000
    landmark_rule: str = "uniform"
    tau_coefficient: float = 1.0
    psd_repair: bool = True


@dataclass
class SketchResult:
    """Outcome of one sketch, including everything needed for the cost table."""

    gram: np.ndarray
    rank: int
    landmarks: np.ndarray
    tau_trunc: float
    negative_mass: float
    min_eigenvalue: float
    executions: float


class ProgressiveNystrom:
    """Incremental Nyström measurements with no repeated quantum columns.

    Landmark identities must be chosen using training data only.  Each call to
    :meth:`acquire` measures only newly requested columns.  The landmark block
    is reused from those column measurements, so accounting is exactly
    ``shots * n_train * n_acquired`` (or one analytic evaluation per entry in
    exact mode).
    """

    def __init__(self, kernel_fn, X: np.ndarray, shots: int | str,
                 rng: np.random.Generator, tau_coefficient: float = 1.0,
                 repair: bool = True):
        self.kernel_fn, self.X, self.shots, self.rng = kernel_fn, X, shots, rng
        self.tau_coefficient, self.repair = tau_coefficient, repair
        self.landmarks = np.empty(0, dtype=int)
        self.columns = np.empty((len(X), 0), dtype=float)
        self.executions = 0.0
        self._pinv = np.empty((0, 0))

    def acquire(self, indices) -> int:
        indices = np.asarray(indices, dtype=int)
        if indices.ndim != 1 or np.any(indices < 0) or np.any(indices >= len(self.X)):
            raise ValueError("landmark indices must be a valid one-dimensional array")
        existing = set(self.landmarks.tolist())
        new = np.array([i for i in indices if int(i) not in existing], dtype=int)
        if len(new) == 0:
            return 0
        block = apply_shot_noise(self.kernel_fn(self.X, self.X[new]),
                                 self.shots, self.rng)
        self.columns = np.hstack([self.columns, block])
        self.landmarks = np.r_[self.landmarks, new]
        shots = 1 if self.shots == "exact" else int(self.shots)
        self.executions += float(shots) * len(self.X) * len(new)
        self._refresh_inverse()
        return len(new)

    def _refresh_inverse(self):
        m = len(self.landmarks)
        W = self.columns[self.landmarks, :]
        W = 0.5 * (W + W.T)
        ev, V = np.linalg.eigh(W)
        tau = 1e-10 if self.shots == "exact" else (
            self.tau_coefficient * math.sqrt(m / (4.0 * int(self.shots))))
        keep = ev > max(tau, 1e-12)
        self._pinv = ((V[:, keep] / ev[keep]) @ V[:, keep].T
                      if np.any(keep) else np.zeros_like(W))
        self.rank = int(keep.sum())
        self.tau_trunc = float(tau)

    def gram(self) -> np.ndarray:
        if len(self.landmarks) == 0:
            raise RuntimeError("acquire at least one landmark first")
        K = self.columns @ self._pinv @ self.columns.T
        return psd_repair(K)[0] if self.repair else 0.5 * (K + K.T)

    def cross_from_columns(self, cross_columns: np.ndarray) -> np.ndarray:
        """Reconstruct K(new, train) from measured K(new, landmarks)."""
        cross_columns = np.asarray(cross_columns, dtype=float)
        if cross_columns.shape[1] != len(self.landmarks):
            raise ValueError("cross columns must match acquired landmarks")
        return cross_columns @ self._pinv @ self.columns.T


# --------------------------------------------------------------------------- #
# Landmark selection
# --------------------------------------------------------------------------- #
def _kmeans_indices(X: np.ndarray, m: int, rng: np.random.Generator,
                    iters: int = 25) -> np.ndarray:
    """Lightweight k-means++ then nearest-sample-to-centroid selection.

    Implemented locally so the package has no hard scikit-learn dependency.
    """
    n = len(X)
    centers = [X[rng.integers(n)]]
    for _ in range(m - 1):
        d2 = np.min([((X - c) ** 2).sum(1) for c in centers], axis=0)
        total = d2.sum()
        probs = d2 / total if total > 0 else np.full(n, 1.0 / n)
        centers.append(X[rng.choice(n, p=probs)])
    C = np.array(centers)
    for _ in range(iters):
        assign = np.argmin(((X[:, None, :] - C[None, :, :]) ** 2).sum(-1), axis=1)
        for k in range(len(C)):
            members = X[assign == k]
            if len(members):
                C[k] = members.mean(0)
    idx = [int(np.argmin(((X - c) ** 2).sum(1))) for c in C]
    return np.unique(np.array(idx))


def select_landmarks(X: np.ndarray, m: int, rule: str,
                     rng: np.random.Generator) -> np.ndarray:
    """Choose landmark indices under the requested rule."""
    n = len(X)
    m = min(m, n)
    if rule == "uniform":
        return rng.choice(n, size=m, replace=False)
    if rule == "kmeans":
        return _kmeans_indices(X, m, rng)
    raise ValueError(f"unknown landmark rule: {rule!r}")


# --------------------------------------------------------------------------- #
# Sketch
# --------------------------------------------------------------------------- #
def psd_repair(K: np.ndarray) -> tuple[np.ndarray, float, float]:
    """Clip negative eigenvalues; report the mass removed and the minimum.

    Returns ``(repaired, negative_mass, min_eigenvalue_before)``.
    """
    sym = 0.5 * (K + K.T)
    ev, V = np.linalg.eigh(sym)
    neg_mass = float(np.abs(ev[ev < 0]).sum())
    repaired = (V * np.clip(ev, 0.0, None)) @ V.T
    return 0.5 * (repaired + repaired.T), neg_mass, float(ev.min())


def nystrom_sketch(kernel_fn, X: np.ndarray, cfg: SketchConfig,
                   rng: np.random.Generator) -> SketchResult:
    r"""Shot-noisy Nystrom sketch with noise-aware truncation.

    Steps: sample ``m`` landmarks; measure the landmark block ``W`` and the
    column block ``C`` under shot noise; discard eigenvalues of ``W`` below
    ``tau_trunc = tau_c sqrt(m/(4s))``; form ``C W^+ C^T``; optionally repair
    PSD. The execution count is recorded exactly, not estimated.
    """
    land = select_landmarks(X, cfg.m, cfg.landmark_rule, rng)
    m_eff = len(land)
    W = apply_shot_noise(kernel_fn(X[land], X[land]), cfg.shots, rng,
                         symmetric=True)
    C = apply_shot_noise(kernel_fn(X, X[land]), cfg.shots, rng)

    if cfg.shots == "exact":
        tau = 1e-10
    else:
        tau = cfg.tau_coefficient * math.sqrt(m_eff / (4.0 * int(cfg.shots)))

    ev, V = np.linalg.eigh(0.5 * (W + W.T))
    keep = ev > max(tau, 1e-12)
    W_pinv = (V[:, keep] / ev[keep]) @ V[:, keep].T
    gram = C @ W_pinv @ C.T

    if cfg.psd_repair:
        gram, neg_mass, min_ev = psd_repair(gram)
    else:
        sym = 0.5 * (gram + gram.T)
        ev_raw = np.linalg.eigvalsh(sym)
        neg_mass = float(np.abs(ev_raw[ev_raw < 0]).sum())
        min_ev = float(ev_raw.min())
        gram = sym

    shots = 1 if cfg.shots == "exact" else int(cfg.shots)
    return SketchResult(
        gram=gram,
        rank=int(keep.sum()),
        landmarks=land,
        tau_trunc=float(tau),
        negative_mass=neg_mass,
        min_eigenvalue=min_ev,
        executions=executions_sketch(len(X), m_eff, shots),
    )


# --------------------------------------------------------------------------- #
# Circuit-execution accounting (the hardware-independent cost claim)
# --------------------------------------------------------------------------- #
def executions_exact(N: int, shots: int) -> float:
    """``s * N(N+1)/2`` executions for the full symmetric Gram matrix."""
    return float(shots) * N * (N + 1) / 2.0


def executions_sketch(N: int, m: int, shots: int) -> float:
    """``s * (N m + m(m+1)/2)`` executions for columns plus landmark block."""
    return float(shots) * (N * m + m * (m + 1) / 2.0)
