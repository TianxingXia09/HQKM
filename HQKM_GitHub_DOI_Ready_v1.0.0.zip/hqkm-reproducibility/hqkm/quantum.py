"""Quantum feature maps and kernels on a classical statevector simulator.

Every encoding here is *classically simulable by construction*: the product
encoding has a closed form, and the entangled ansatz is evaluated on explicit
2**n-dimensional real statevectors. This is deliberate -- the experiments test
the *machinery* (criterion, certificate, estimator) under exactly measurable
ground truth. No quantum-advantage claim is made or possible from this code.

Shot noise is applied as an explicit binomial layer on top of the exact
fidelities, so the estimator is exercised under realistic finite-sampling
conditions while the exact Gram matrix remains available as ground truth.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np

__all__ = [
    "EncodingConfig",
    "product_kernel",
    "entangled_features",
    "entangled_kernel",
    "quantum_kernel_fn",
    "apply_shot_noise",
    "sample_expectation",
    "z0_observable",
]


# --------------------------------------------------------------------------- #
# Configuration
# --------------------------------------------------------------------------- #
@dataclass(frozen=True)
class EncodingConfig:
    """Encoding hyperparameters.

    Parameters
    ----------
    n_qubits:
        Number of qubits. The simulator holds a dense ``2 ** n_qubits`` real
        statevector, so keep this modest (<= 14 is comfortable).
    scale:
        Encoding scale ``s_q``. This is the paper's bandwidth knob: it controls
        both the benefit region and the estimation cost.
    family:
        ``"product"`` (closed form) or ``"entangled"`` (RY - CZ ring - RY with
        data re-uploading).
    layers:
        Number of ``CZ ring + RY`` blocks for the entangled family.
    """

    n_qubits: int = 6
    scale: float = 1.0
    family: str = "entangled"
    layers: int = 1

    def __post_init__(self) -> None:
        if self.family not in ("product", "entangled"):
            raise ValueError(f"unknown encoding family: {self.family!r}")
        if self.n_qubits < 1:
            raise ValueError("n_qubits must be >= 1")


# --------------------------------------------------------------------------- #
# Product encoding (closed form)
# --------------------------------------------------------------------------- #
def product_kernel(X: np.ndarray, Y: np.ndarray | None = None,
                   scale: float = 1.0) -> np.ndarray:
    r"""Product-encoding kernel :math:`\prod_i \cos^2(s_q (x_i - y_i)/2)`.

    This is the fidelity of a product state ``\otimes_i RY(s_q x_i)|0>`` and has
    an exact closed form, so it costs :math:`O(N^2 d)` classically and needs no
    statevector construction.
    """
    Y = X if Y is None else Y
    if X.shape[1] != Y.shape[1]:
        raise ValueError("X and Y must have the same number of features")
    out = np.ones((X.shape[0], Y.shape[0]))
    for i in range(X.shape[1]):
        out *= np.cos(0.5 * scale * (X[:, i, None] - Y[None, :, i])) ** 2
    return out


# --------------------------------------------------------------------------- #
# Entangled encoding (explicit statevector)
# --------------------------------------------------------------------------- #
def _apply_ry(state: np.ndarray, qubit: int, theta: float,
              n_qubits: int) -> np.ndarray:
    """Apply ``RY(theta)`` to ``qubit`` of a real statevector, in place-safe."""
    cos_t, sin_t = math.cos(theta), math.sin(theta)
    tensor = state.reshape((2,) * n_qubits).copy()
    moved = np.moveaxis(tensor, qubit, 0)
    a0, a1 = moved[0].copy(), moved[1].copy()
    moved[0] = cos_t * a0 - sin_t * a1
    moved[1] = sin_t * a0 + cos_t * a1
    return tensor.reshape(-1)


def _apply_cz_ring(state: np.ndarray, n_qubits: int) -> np.ndarray:
    """Apply a ring of controlled-Z gates (a diagonal Clifford)."""
    tensor = state.reshape((2,) * n_qubits).copy()
    for q in range(n_qubits):
        index: list = [slice(None)] * n_qubits
        index[q] = 1
        index[(q + 1) % n_qubits] = 1
        tensor[tuple(index)] *= -1.0
    return tensor.reshape(-1)


def entangled_features(X: np.ndarray, cfg: EncodingConfig,
                       theta: np.ndarray | None = None) -> np.ndarray:
    """Statevector features for the re-uploaded RY - CZ ring - RY ansatz.

    The second ``RY`` layer *re-uploads the data*. This is not cosmetic: a
    trailing diagonal Clifford cancels in the fidelity, so without re-uploading
    the CZ ring would leave the kernel unchanged. When ``theta`` is given, the
    post-CZ rotations use those trainable angles instead of the data -- this is
    how the QNN baseline reuses the same circuit.

    Returns
    -------
    ndarray of shape ``(n_samples, 2 ** n_qubits)``
        Real amplitudes.
    """
    n, dim = cfg.n_qubits, 2 ** cfg.n_qubits
    out = np.empty((X.shape[0], dim))
    for row, x in enumerate(X):
        psi = np.zeros(dim)
        psi[0] = 1.0
        for q in range(n):
            psi = _apply_ry(psi, q, cfg.scale * x[q % X.shape[1]], n)
        for layer in range(cfg.layers):
            psi = _apply_cz_ring(psi, n)
            for q in range(n):
                angle = (theta[layer * n + q] if theta is not None
                         else cfg.scale * x[q % X.shape[1]])
                psi = _apply_ry(psi, q, angle, n)
        out[row] = psi
    return out


def entangled_kernel(X: np.ndarray, Y: np.ndarray | None = None,
                     cfg: EncodingConfig | None = None) -> np.ndarray:
    r"""Fidelity kernel :math:`|\langle \psi(x) | \psi(y) \rangle|^2`."""
    cfg = cfg or EncodingConfig()
    fx = entangled_features(X, cfg)
    fy = fx if Y is None else entangled_features(Y, cfg)
    return (fx @ fy.T) ** 2


def quantum_kernel_fn(cfg: EncodingConfig):
    """Return a ``(X, Y=None) -> Gram`` callable for the configured encoding."""
    if cfg.family == "product":
        return lambda X, Y=None: product_kernel(X, Y, cfg.scale)
    return lambda X, Y=None: entangled_kernel(X, Y, cfg)


# --------------------------------------------------------------------------- #
# Shot noise and observables
# --------------------------------------------------------------------------- #
def apply_shot_noise(gram: np.ndarray, shots: int | str,
                     rng: np.random.Generator,
                     symmetric: bool = False) -> np.ndarray:
    """Binomial shot noise on kernel entries.

    Each entry of a fidelity Gram matrix is a Bernoulli success probability, so
    ``s`` shots give an unbiased estimate with variance ``p(1-p)/s <= 1/(4s)``.
    Pass ``shots="exact"`` for the noiseless (infinite-shot) limit.
    """
    if shots == "exact":
        return gram
    shots = int(shots)
    if shots <= 0:
        raise ValueError("shots must be positive or 'exact'")
    probs = np.clip(gram, 0.0, 1.0)
    if symmetric:
        if gram.ndim != 2 or gram.shape[0] != gram.shape[1]:
            raise ValueError("symmetric shot sampling requires a square matrix")
        out = np.empty_like(probs, dtype=float)
        upper = np.triu_indices(len(probs))
        sampled = rng.binomial(shots, probs[upper]) / float(shots)
        out[upper] = sampled
        out[(upper[1], upper[0])] = sampled
        return out
    return rng.binomial(shots, probs) / float(shots)


def sample_expectation(values: np.ndarray, shots: int | str,
                       rng: np.random.Generator) -> np.ndarray:
    """Sample an observable in [-1, 1] from finite Bernoulli shots."""
    values = np.clip(np.asarray(values, dtype=float), -1.0, 1.0)
    if shots == "exact":
        return values
    shots = int(shots)
    if shots <= 0:
        raise ValueError("shots must be positive or 'exact'")
    successes = rng.binomial(shots, (values + 1.0) / 2.0)
    return 2.0 * successes / float(shots) - 1.0


def z0_observable(n_qubits: int) -> np.ndarray:
    """Diagonal of :math:`Z_0` in the basis used by ``reshape((2,) * n)``.

    With that reshape qubit 0 is the most significant bit, so the first half of
    the amplitudes carries eigenvalue ``+1``.
    """
    idx = np.arange(2 ** n_qubits)
    return np.where(idx < 2 ** (n_qubits - 1), 1.0, -1.0)
