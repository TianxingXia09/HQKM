"""All models compared in the paper, behind one interface.

The roles are exactly those the experiment design requires:

============================  ====================================================
class                         role
============================  ====================================================
``SingleClassicalKernel``     cheap classical reference: best single tuned kernel
``ClassicalMKL``              **primary baseline** -- identical code path to the
                              proposed method with the quantum kernel removed
``QuantumOnly``               quantum kernel alone, exact or sketched
``AlignmentTrainedQuantum``   SOTA contrast: encoding scale trained by alignment
``QuantumNeuralNetwork``      SOTA contrast: variational model, SPSA-trained
``EmulatorPipeline``          closest-prior-art mechanism: Nystrom + k-means
                              landmarks + classical surrogate, no criterion, no
                              PSD repair
``HybridMKL``                 the proposed method
============================  ====================================================

Fairness constraints are enforced structurally rather than by convention: all
kernel models share the ridge solver, the lambda grid, the sketch budget and the
splits, and ``ClassicalMKL`` is literally ``HybridMKL`` with an empty quantum
slot. Any number reported for the prior-art pipeline is measured here, never
copied from a paper.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from .criterion import benefit_criterion, bound_gap, redundancy_certificate
from .estimator import (ProgressiveNystrom, SketchConfig, executions_exact,
                        nystrom_sketch, select_landmarks)
from .kernels import (alignment, build_dictionary, effective_dimension,
                      kernel_ridge_predict, normalize_gram,
                      solve_mkl_alignment)
from .metrics import auc_score
from .quantum import (EncodingConfig, apply_shot_noise, entangled_features,
                      quantum_kernel_fn, sample_expectation, z0_observable)

__all__ = [
    "ModelConfig",
    "BaseModel",
    "SingleClassicalKernel",
    "ClassicalMKL",
    "QuantumOnly",
    "AlignmentTrainedQuantum",
    "QuantumNeuralNetwork",
    "EmulatorPipeline",
    "HybridMKL",
    "BudgetedHybridMKL",
    "ALL_MODELS",
    "build_model",
]


@dataclass
class ModelConfig:
    """Shared hyperparameters. Identical across models by construction."""

    lambda_grid: tuple[float, ...] = (0.03, 0.01, 0.003, 0.001)
    mkl_iters: int = 200
    mkl_lr: float = 0.05
    lam_deff: float = 0.01
    sketch: SketchConfig = field(default_factory=SketchConfig)
    encoding: EncodingConfig = field(default_factory=EncodingConfig)
    use_sketch: bool = False
    centered_alignment: bool = True
    qnn_layers: int = 2
    qnn_iters: int = 300
    scale_grid: tuple[float, ...] = (0.25, 0.5, 1.0, 1.5, 2.0)
    acquisition_rounds: tuple[int, ...] = (10, 20, 40, 80)
    acquisition_strategy: str = "residual"
    acquisition_metric: str = "accuracy"
    acquisition_cost_penalty: float = 0.01
    acquisition_min_improvement: float = 0.0
    acquisition_patience: int = 2
    acquisition_accuracy_weight: float = 0.5
    acquisition_auc_weight: float = 0.5
    acquisition_residual_weight: float = 0.35
    acquisition_uncertainty_weight: float = 0.35
    acquisition_diversity_weight: float = 0.30
    acquisition_max_executions: float | None = None
    acquisition_min_efficiency: float = 0.0


class BaseModel:
    """Common fit / score interface.

    Subclasses implement ``_fit``. ``executions`` accumulates quantum circuit
    executions actually spent, which is the hardware-independent cost unit; a
    model that touches no quantum kernel reports zero.
    """

    name = "base"

    def __init__(self, cfg: ModelConfig, rng: np.random.Generator):
        self.cfg = cfg
        self.rng = rng
        self.executions = 0.0
        self.info: dict = {}
        self._X: np.ndarray | None = None
        self._y: np.ndarray | None = None
        self._alpha: np.ndarray | None = None
        self._lam = cfg.lambda_grid[0]

    # -- public API -------------------------------------------------------- #
    def fit(self, X: np.ndarray, y: np.ndarray,
            X_tune: np.ndarray | None = None,
            y_tune: np.ndarray | None = None) -> "BaseModel":
        self._X, self._y = X, y
        self._fit(X, y, X_tune, y_tune)
        return self

    def decision_function(self, X: np.ndarray) -> np.ndarray:
        raise NotImplementedError

    # -- helpers ----------------------------------------------------------- #
    def _tune_lambda(self, K_train, y, K_tune_train, y_tune) -> float:
        """Pick lambda on the tuning split only."""
        if y_tune is None:
            return self.cfg.lambda_grid[0]
        best = (-np.inf, self.cfg.lambda_grid[0])
        for lam in self.cfg.lambda_grid:
            scores = kernel_ridge_predict(K_train, y, K_tune_train, lam)
            acc = float((np.sign(scores) == y_tune).mean())
            if acc > best[0]:
                best = (acc, lam)
        return best[1]

    def _fit(self, X, y, X_tune, y_tune):  # pragma: no cover - abstract
        raise NotImplementedError


# --------------------------------------------------------------------------- #
# 1. Best single tuned classical kernel
# --------------------------------------------------------------------------- #
class SingleClassicalKernel(BaseModel):
    """Cheap classical reference. Kernel *and* lambda chosen on the tuning split."""

    name = "classical_single"

    def _fit(self, X, y, X_tune, y_tune):
        dictionary = build_dictionary()
        best = (-np.inf, None, self.cfg.lambda_grid[0])
        for kname, fn in dictionary:
            K_tr = normalize_gram(fn(X))
            K_tu = fn(X_tune, X) if X_tune is not None else None
            for lam in self.cfg.lambda_grid:
                if K_tu is None:
                    score = alignment(K_tr, y, self.cfg.centered_alignment)
                else:
                    pred = kernel_ridge_predict(K_tr, y, normalize_gram(K_tu), lam)
                    score = float((np.sign(pred) == y_tune).mean())
                if score > best[0]:
                    best = (score, (kname, fn), lam)
        _, (kname, fn), lam = best
        self._fn, self._lam = fn, lam
        K_tr = normalize_gram(fn(X))
        self._alpha = np.linalg.solve(K_tr + lam * len(y) * np.eye(len(y)), y)
        self._scale = max(float(np.linalg.norm(fn(X))), 1e-12)
        self.info = dict(kernel=kname, lam=lam,
                         d_eff=effective_dimension(K_tr, self.cfg.lam_deff),
                         alignment=alignment(K_tr, y, self.cfg.centered_alignment))

    def decision_function(self, X):
        return (self._fn(X, self._X) / self._scale) @ self._alpha


# --------------------------------------------------------------------------- #
# 2 & 7. MKL over the dictionary, with or without the quantum kernel
# --------------------------------------------------------------------------- #
class _MKLBase(BaseModel):
    """Shared implementation; ``include_quantum`` is the only difference."""

    include_quantum = False

    def _fit(self, X, y, X_tune, y_tune):
        dictionary = build_dictionary()
        self._dict = dictionary
        grams = [normalize_gram(fn(X)) for _, fn in dictionary]
        names = [n for n, _ in dictionary]
        K_classical = None
        self._qfn = None

        if self.include_quantum:
            qfn = quantum_kernel_fn(self.cfg.encoding)
            self._qfn = qfn
            if self.cfg.use_sketch:
                res = nystrom_sketch(qfn, X, self.cfg.sketch, self.rng)
                Kq = res.gram
                self.executions += res.executions
                self.info["sketch_rank"] = res.rank
                self.info["tau_trunc"] = res.tau_trunc
                self.info["negative_mass"] = res.negative_mass
                self._q_landmarks = res.landmarks
            else:
                Kq = apply_shot_noise(qfn(X), self.cfg.sketch.shots,
                                      self.rng, symmetric=True)
                shots = 1 if self.cfg.sketch.shots == "exact" else int(self.cfg.sketch.shots)
                self.executions += executions_exact(len(X), shots)
                self._q_landmarks = None
            self._q_scale = max(float(np.linalg.norm(Kq)), 1e-12)
            Kq = Kq / self._q_scale
            K_classical = sum(g / len(grams) for g in grams)
            grams = grams + [Kq]
            names = names + ["quantum"]

        beta, history = solve_mkl_alignment(
            grams, y, self.cfg.mkl_iters, self.cfg.mkl_lr,
            centered=self.cfg.centered_alignment, return_history=True)
        self._beta, self._names = beta, names
        K_train = sum(b * g for b, g in zip(beta, grams))

        # lambda on the tuning split, using the same weights
        K_tune_train = self._cross_gram(X_tune, X, beta) if X_tune is not None else None
        self._lam = self._tune_lambda(K_train, y, K_tune_train, y_tune)
        n = len(y)
        self._alpha = np.linalg.solve(K_train + self._lam * n * np.eye(n), y)
        tune_accuracy = None
        if K_tune_train is not None and y_tune is not None:
            tune_scores = K_tune_train @ self._alpha
            tune_accuracy = float((np.sign(tune_scores) == y_tune).mean())

        self.info.update(
            weights=dict(zip(names, np.round(beta, 4).tolist())),
            beta_quantum=float(beta[-1]) if self.include_quantum else 0.0,
            lam=self._lam,
            alignment=alignment(K_train, y, self.cfg.centered_alignment),
            d_eff=effective_dimension(K_train, self.cfg.lam_deff),
            mkl_iterations=len(history),
            mkl_final_objective=history[-1],
            tune_accuracy=tune_accuracy,
        )
        if self.include_quantum and K_classical is not None:
            beta_c = solve_mkl_alignment(grams[:-1], y, self.cfg.mkl_iters,
                                         self.cfg.mkl_lr,
                                         centered=self.cfg.centered_alignment)
            K_c = sum(b * g for b, g in zip(beta_c, grams[:-1]))
            crit = benefit_criterion(K_c, K_train, y, self.cfg.lam_deff,
                                     self.cfg.centered_alignment)
            self.info.update(
                phi=crit.phi, delta_alignment=crit.delta_alignment,
                phi_floor_active=crit.floor_active,
                d_eff_classical=crit.d_eff_classical,
                bound_gap=bound_gap(K_c, K_train, y, self.cfg.lam_deff,
                                    centered=self.cfg.centered_alignment),
            )
        self._train_grams_fns = [fn for _, fn in dictionary]

    def _cross_gram(self, X_new, X_train, beta):
        if X_new is None:
            return None
        parts = []
        for _, fn in self._dict:
            K_full = fn(X_train)
            parts.append(fn(X_new, X_train) / max(float(np.linalg.norm(K_full)), 1e-12))
        if self.include_quantum:
            q_cross = apply_shot_noise(self._qfn(X_new, X_train),
                                       self.cfg.sketch.shots, self.rng)
            parts.append(q_cross
                         / self._q_scale)
            shots = 1 if self.cfg.sketch.shots == "exact" else int(self.cfg.sketch.shots)
            self.executions += float(shots) * len(X_new) * len(X_train)
        return sum(b * P for b, P in zip(beta, parts))

    def decision_function(self, X):
        K = self._cross_gram(X, self._X, self._beta)
        return K @ self._alpha


class ClassicalMKL(_MKLBase):
    """Primary baseline: same dictionary, same solver, no quantum kernel."""

    name = "classical_mkl"
    include_quantum = False


class HybridMKL(_MKLBase):
    """The proposed method: dictionary plus one quantum kernel."""

    name = "hybrid_mkl"
    include_quantum = True


class BudgetedHybridMKL(BaseModel):
    """Sequential hybrid MKL that buys quantum landmark columns on demand.

    Landmark ranking uses training residuals (or training uncertainty) only.
    The tuning split chooses the stopping round; test data are queried once,
    after the acquisition path has been frozen.
    """

    name = "budgeted_hybrid_mkl"

    @staticmethod
    def _unit_rank(values):
        """Stable [0,1] ranks; used to combine heterogeneous acquisition cues."""
        values = np.asarray(values, dtype=float)
        if len(values) <= 1:
            return np.ones(len(values), dtype=float)
        order = np.argsort(values, kind="mergesort")
        ranks = np.empty(len(values), dtype=float)
        ranks[order] = np.linspace(0.0, 1.0, len(values))
        return ranks

    def _multiobjective_batch(self, X, scores, selected, batch_size):
        """Select a training-only batch from error, uncertainty and diversity.

        Diversity is recomputed after every selected point (greedy farthest-first),
        so a batch cannot collapse onto one difficult but redundant region.
        """
        n = len(X)
        selected = list(map(int, selected))
        available = np.ones(n, dtype=bool)
        available[selected] = False
        chosen = []
        residual = self._unit_rank(np.abs(self._y - scores))
        uncertainty = self._unit_rank(-np.abs(scores))
        center = X.mean(axis=0, keepdims=True)
        while len(chosen) < batch_size and available.any():
            anchors = selected + chosen
            if anchors:
                distance = np.min(
                    np.sum((X[:, None, :] - X[np.asarray(anchors)][None, :, :]) ** 2,
                           axis=2), axis=1)
            else:
                distance = np.sum((X - center) ** 2, axis=1)
            diversity = self._unit_rank(distance)
            priority = (self.cfg.acquisition_residual_weight * residual
                        + self.cfg.acquisition_uncertainty_weight * uncertainty
                        + self.cfg.acquisition_diversity_weight * diversity)
            priority[~available] = -np.inf
            idx = int(np.argmax(priority))
            chosen.append(idx)
            available[idx] = False
        return np.asarray(chosen, dtype=int)

    def _fit(self, X, y, X_tune, y_tune):
        if X_tune is None or y_tune is None:
            raise ValueError("budgeted acquisition requires a tuning split")
        rounds = tuple(sorted(set(min(int(m), len(X))
                                  for m in self.cfg.acquisition_rounds if int(m) > 0)))
        if not rounds:
            raise ValueError("acquisition_rounds must contain a positive value")
        if self.cfg.acquisition_strategy not in ("residual", "uncertainty", "random", "kmeans",
                                                  "multiobjective"):
            raise ValueError("unknown acquisition_strategy")
        if self.cfg.acquisition_metric not in ("accuracy", "auc", "multiobjective"):
            raise ValueError("acquisition_metric must be accuracy, auc or multiobjective")
        cue_weights = (self.cfg.acquisition_residual_weight,
                       self.cfg.acquisition_uncertainty_weight,
                       self.cfg.acquisition_diversity_weight)
        if min(cue_weights) < 0 or not np.isclose(sum(cue_weights), 1.0):
            raise ValueError("multiobjective acquisition cue weights must be nonnegative and sum to one")
        metric_weights = (self.cfg.acquisition_accuracy_weight,
                          self.cfg.acquisition_auc_weight)
        if min(metric_weights) < 0 or not np.isclose(sum(metric_weights), 1.0):
            raise ValueError("multiobjective metric weights must be nonnegative and sum to one")

        self._dict = build_dictionary()
        classical = [normalize_gram(fn(X)) for _, fn in self._dict]
        beta_c = solve_mkl_alignment(classical, y, self.cfg.mkl_iters,
                                     self.cfg.mkl_lr,
                                     centered=self.cfg.centered_alignment)
        Kc = sum(b * g for b, g in zip(beta_c, classical))
        Kc_tune = self._classical_cross(X_tune, X, beta_c)
        lam_c = self._tune_lambda(Kc, y, Kc_tune, y_tune)
        alpha_c = np.linalg.solve(Kc + lam_c * len(y) * np.eye(len(y)), y)
        tune_c = float((np.sign(Kc_tune @ alpha_c) == y_tune).mean())
        auc_c = float(auc_score(Kc_tune @ alpha_c, y_tune))
        train_scores = Kc @ alpha_c
        if self.cfg.acquisition_strategy == "residual":
            priority = np.abs(y - train_scores)
            order = np.argsort(-(priority + self.rng.uniform(0, 1e-12, len(priority))))
        elif self.cfg.acquisition_strategy == "uncertainty":
            priority = -np.abs(train_scores)
            order = np.argsort(-(priority + self.rng.uniform(0, 1e-12, len(priority))))
        elif self.cfg.acquisition_strategy == "random":
            order = self.rng.permutation(len(X))
        elif self.cfg.acquisition_strategy == "kmeans":
            initial = select_landmarks(X, rounds[-1], "kmeans", self.rng)
            missing = np.setdiff1d(np.arange(len(X)), initial, assume_unique=True)
            order = np.r_[initial, self.rng.permutation(missing)]
        else:
            order = None

        qfn = quantum_kernel_fn(self.cfg.encoding)
        prog = ProgressiveNystrom(qfn, X, self.cfg.sketch.shots, self.rng,
                                  self.cfg.sketch.tau_coefficient,
                                  self.cfg.sketch.psd_repair)
        q_tune_columns = np.empty((len(X_tune), 0))
        shots = 1 if self.cfg.sketch.shots == "exact" else int(self.cfg.sketch.shots)
        max_cost = float(shots * (len(X) + len(X_tune)) * rounds[-1])
        history, best_utility, stale = [], 0.0, 0
        if self.cfg.acquisition_metric == "accuracy":
            baseline_metric = tune_c
        elif self.cfg.acquisition_metric == "auc":
            baseline_metric = auc_c
        else:
            baseline_metric = (self.cfg.acquisition_accuracy_weight * tune_c
                               + self.cfg.acquisition_auc_weight * auc_c)
        best = dict(beta=beta_c, alpha=alpha_c, lam=lam_c, tune=tune_c,
                    tune_auc=auc_c,
                    quantum=False)
        current_train_scores = train_scores
        previous_metric = baseline_metric
        budget_exhausted = False

        for target in rounds:
            batch_size = target - len(prog.landmarks)
            projected = self.executions + float(shots) * (len(X) + len(X_tune)) * batch_size
            if (self.cfg.acquisition_max_executions is not None
                    and projected > self.cfg.acquisition_max_executions):
                budget_exhausted = True
                break
            if self.cfg.acquisition_strategy == "multiobjective":
                new_idx = self._multiobjective_batch(
                    X, current_train_scores, prog.landmarks, batch_size)
            else:
                new_idx = order[len(prog.landmarks):target]
            acquired = prog.acquire(new_idx)
            if acquired:
                q_new = apply_shot_noise(qfn(X_tune, X[new_idx]),
                                         self.cfg.sketch.shots, self.rng)
                q_tune_columns = np.hstack([q_tune_columns, q_new])
                self.executions += float(shots) * len(X_tune) * acquired
            self.executions += float(shots) * len(X) * acquired
            Kq_raw = prog.gram()
            q_scale = max(float(np.linalg.norm(Kq_raw)), 1e-12)
            Kq = Kq_raw / q_scale
            Kq_tune = prog.cross_from_columns(q_tune_columns) / q_scale
            grams = classical + [Kq]
            beta = solve_mkl_alignment(grams, y, self.cfg.mkl_iters,
                                       self.cfg.mkl_lr,
                                       centered=self.cfg.centered_alignment)
            K = sum(b * g for b, g in zip(beta, grams))
            K_tune = self._classical_cross(X_tune, X, beta[:-1]) + beta[-1] * Kq_tune
            lam = self._tune_lambda(K, y, K_tune, y_tune)
            alpha = np.linalg.solve(K + lam * len(y) * np.eye(len(y)), y)
            tune = float((np.sign(K_tune @ alpha) == y_tune).mean())
            tune_auc = float(auc_score(K_tune @ alpha, y_tune))
            fraction = self.executions / max(max_cost, 1.0)
            if self.cfg.acquisition_metric == "accuracy":
                current_metric = tune
            elif self.cfg.acquisition_metric == "auc":
                current_metric = tune_auc
            else:
                current_metric = (self.cfg.acquisition_accuracy_weight * tune
                                  + self.cfg.acquisition_auc_weight * tune_auc)
            utility = current_metric - baseline_metric - self.cfg.acquisition_cost_penalty * fraction
            incremental_gain = current_metric - previous_metric
            incremental_cost_million = (float(shots) * (len(X) + len(X_tune))
                                        * max(acquired, 1) / 1e6)
            efficiency = incremental_gain / max(incremental_cost_million, 1e-12)
            improved = (utility > best_utility + self.cfg.acquisition_min_improvement
                        and efficiency >= self.cfg.acquisition_min_efficiency)
            history.append(dict(landmarks=len(prog.landmarks), rank=prog.rank,
                                tune_accuracy=tune, delta_tune=tune-tune_c,
                                tune_auc=tune_auc, delta_tune_auc=tune_auc-auc_c,
                                cost_fraction=fraction, utility=utility,
                                incremental_gain=incremental_gain,
                                gain_per_million_executions=efficiency,
                                executions=self.executions, improved=bool(improved)))
            current_train_scores = K @ alpha
            previous_metric = current_metric
            if improved:
                best_utility, stale = utility, 0
                best = dict(beta=beta.copy(), alpha=alpha.copy(), lam=lam,
                            tune=tune, quantum=True, q_scale=q_scale,
                            tune_auc=tune_auc,
                            landmarks=prog.landmarks.copy(),
                            columns=prog.columns.copy(), pinv=prog._pinv.copy())
            else:
                stale += 1
            if stale >= self.cfg.acquisition_patience:
                break

        self._beta, self._alpha, self._lam = best["beta"], best["alpha"], best["lam"]
        self._uses_quantum, self._qfn = best["quantum"], qfn
        if self._uses_quantum:
            self._q_scale, self._q_landmarks = best["q_scale"], best["landmarks"]
            self._q_columns, self._q_pinv = best["columns"], best["pinv"]
        self.info = dict(weights=dict(zip(
            [n for n, _ in self._dict] + (["quantum"] if self._uses_quantum else []),
            np.round(self._beta, 4).tolist())),
            beta_quantum=float(self._beta[-1]) if self._uses_quantum else 0.0,
            lam=self._lam, tune_accuracy=best["tune"],
            tune_auc=best["tune_auc"],
            classical_tune_accuracy=tune_c, selected_quantum=self._uses_quantum,
            selected_landmarks=(len(self._q_landmarks) if self._uses_quantum else 0),
            acquired_landmarks=len(prog.landmarks), acquisition_history=history,
            acquisition_strategy=self.cfg.acquisition_strategy,
            acquisition_metric=self.cfg.acquisition_metric,
            budget_exhausted=budget_exhausted,
            acquisition_max_executions=self.cfg.acquisition_max_executions,
            pre_acquisition_meta_features={
                "log_n_train": float(np.log1p(len(X))),
                "log_n_features": float(np.log1p(X.shape[1])),
                "positive_rate_train": float(np.mean(y > 0)),
                "class_imbalance_train": float(abs(np.mean(y > 0) - 0.5) * 2.0),
                "classical_alignment": float(alignment(
                    Kc, y, self.cfg.centered_alignment)),
                "classical_effective_dimension": float(effective_dimension(
                    Kc, self.cfg.lam_deff)),
                "classical_tune_accuracy": tune_c,
                "classical_tune_auc": auc_c,
                "mean_abs_classical_margin_train": float(np.mean(np.abs(train_scores))),
                "mean_classical_residual_train": float(np.mean(np.abs(y-train_scores))),
            },
            exploration_executions=self.executions)

    def _classical_cross(self, X_new, X_train, beta):
        total = np.zeros((len(X_new), len(X_train)))
        for b, (_, fn) in zip(beta, self._dict):
            scale = max(float(np.linalg.norm(fn(X_train))), 1e-12)
            total += b * fn(X_new, X_train) / scale
        return total

    def decision_function(self, X):
        if not self._uses_quantum:
            return self._classical_cross(X, self._X, self._beta) @ self._alpha
        classical = self._classical_cross(X, self._X, self._beta[:-1])
        qcols = apply_shot_noise(self._qfn(X, self._X[self._q_landmarks]),
                                 self.cfg.sketch.shots, self.rng)
        shots = 1 if self.cfg.sketch.shots == "exact" else int(self.cfg.sketch.shots)
        self.executions += float(shots) * len(X) * len(self._q_landmarks)
        qcross = qcols @ self._q_pinv @ self._q_columns.T / self._q_scale
        return (classical + self._beta[-1] * qcross) @ self._alpha


# --------------------------------------------------------------------------- #
# 3. Quantum kernel alone
# --------------------------------------------------------------------------- #
class QuantumOnly(BaseModel):
    """Quantum kernel ridge regression, exact or Nystrom-sketched."""

    name = "quantum_only"

    def _fit(self, X, y, X_tune, y_tune):
        qfn = quantum_kernel_fn(self.cfg.encoding)
        self._qfn = qfn
        if self.cfg.use_sketch:
            res = nystrom_sketch(qfn, X, self.cfg.sketch, self.rng)
            K = normalize_gram(res.gram)
            self.executions += res.executions
            self.info["sketch_rank"] = res.rank
        else:
            K_noisy = apply_shot_noise(qfn(X), self.cfg.sketch.shots,
                                       self.rng, symmetric=True)
            self._scale = max(float(np.linalg.norm(K_noisy)), 1e-12)
            K = K_noisy / self._scale
            shots = 1 if self.cfg.sketch.shots == "exact" else int(self.cfg.sketch.shots)
            self.executions += executions_exact(len(X), shots)
        if self.cfg.use_sketch:
            self._scale = max(float(np.linalg.norm(res.gram)), 1e-12)
        K_tune = (apply_shot_noise(qfn(X_tune, X), self.cfg.sketch.shots,
                                   self.rng) / self._scale) if X_tune is not None else None
        if X_tune is not None:
            shots = 1 if self.cfg.sketch.shots == "exact" else int(self.cfg.sketch.shots)
            self.executions += float(shots) * len(X_tune) * len(X)
        self._lam = self._tune_lambda(K, y, K_tune, y_tune)
        n = len(y)
        self._alpha = np.linalg.solve(K + self._lam * n * np.eye(n), y)
        self.info.update(lam=self._lam,
                         alignment=alignment(K, y, self.cfg.centered_alignment),
                         d_eff=effective_dimension(K, self.cfg.lam_deff))

    def decision_function(self, X):
        K = apply_shot_noise(self._qfn(X, self._X), self.cfg.sketch.shots,
                             self.rng)
        shots = 1 if self.cfg.sketch.shots == "exact" else int(self.cfg.sketch.shots)
        self.executions += float(shots) * len(X) * len(self._X)
        return (K / self._scale) @ self._alpha


# --------------------------------------------------------------------------- #
# 4a. Alignment-trained quantum kernel (SOTA contrast)
# --------------------------------------------------------------------------- #
class AlignmentTrainedQuantum(BaseModel):
    """Quantum kernel whose encoding scale is trained by alignment maximization.

    This is the current best single-quantum-model practice: instead of a fixed
    encoding, the bandwidth is selected to maximize kernel--target alignment on
    the training split. Same encoding family and qubit budget as our method.
    """

    name = "quantum_aligned"

    def _fit(self, X, y, X_tune, y_tune):
        best = (-np.inf, self.cfg.encoding.scale, None)
        shots = 1 if self.cfg.sketch.shots == "exact" else int(self.cfg.sketch.shots)
        for scale in self.cfg.scale_grid:
            cfg_s = EncodingConfig(self.cfg.encoding.n_qubits, scale,
                                   self.cfg.encoding.family, self.cfg.encoding.layers)
            K_raw = apply_shot_noise(quantum_kernel_fn(cfg_s)(X),
                                     self.cfg.sketch.shots,
                                     self.rng, symmetric=True)
            K = normalize_gram(K_raw)
            self.executions += executions_exact(len(X), shots)
            score = alignment(K, y, self.cfg.centered_alignment)
            if score > best[0]:
                best = (score, scale, K_raw)
        _, scale, K_raw = best
        self._cfg_s = EncodingConfig(self.cfg.encoding.n_qubits, scale,
                                     self.cfg.encoding.family, self.cfg.encoding.layers)
        self._qfn = quantum_kernel_fn(self._cfg_s)
        self._scale_norm = max(float(np.linalg.norm(K_raw)), 1e-12)
        K = K_raw / self._scale_norm
        K_tune = (apply_shot_noise(self._qfn(X_tune, X),
                                   self.cfg.sketch.shots, self.rng)
                  / self._scale_norm) if X_tune is not None else None
        if X_tune is not None:
            self.executions += float(shots) * len(X_tune) * len(X)
        self._lam = self._tune_lambda(K, y, K_tune, y_tune)
        n = len(y)
        self._alpha = np.linalg.solve(K + self._lam * n * np.eye(n), y)
        self.info.update(trained_scale=scale, lam=self._lam,
                         alignment=alignment(K, y, self.cfg.centered_alignment))

    def decision_function(self, X):
        K = apply_shot_noise(self._qfn(X, self._X), self.cfg.sketch.shots,
                             self.rng)
        shots = 1 if self.cfg.sketch.shots == "exact" else int(self.cfg.sketch.shots)
        self.executions += float(shots) * len(X) * len(self._X)
        return (K / self._scale_norm) @ self._alpha


# --------------------------------------------------------------------------- #
# 4b. Quantum neural network (SOTA contrast)
# --------------------------------------------------------------------------- #
class QuantumNeuralNetwork(BaseModel):
    """Variational model on the same circuit family, trained by SPSA.

    Angle encoding, then ``qnn_layers`` blocks of CZ ring plus trainable RY, with
    a ``<Z_0>`` readout and squared loss. SPSA is used because it needs two
    circuit evaluations per step regardless of parameter count, which is the
    standard choice for hardware-oriented QNN training.
    """

    name = "qnn"

    def _fit(self, X, y, X_tune, y_tune):
        n_params = self.cfg.qnn_layers * self.cfg.encoding.n_qubits
        theta = self.rng.normal(0.0, 0.3, n_params)
        obs = z0_observable(self.cfg.encoding.n_qubits)
        enc = EncodingConfig(self.cfg.encoding.n_qubits, self.cfg.encoding.scale,
                             "entangled", self.cfg.qnn_layers)
        shots = 1 if self.cfg.sketch.shots == "exact" else int(self.cfg.sketch.shots)

        def forward(theta_vec, Xb):
            feats = entangled_features(Xb, enc, theta=theta_vec)
            exact = (feats ** 2) @ obs
            return sample_expectation(exact, self.cfg.sketch.shots, self.rng)

        best = (np.inf, theta.copy())
        for k in range(self.cfg.qnn_iters):
            delta = self.rng.choice((-1.0, 1.0), n_params)
            c_k = 0.2 / (k + 1) ** 0.101
            a_k = 0.5 / (k + 1) ** 0.602
            loss_p = float(((forward(theta + c_k * delta, X) - y) ** 2).mean())
            loss_m = float(((forward(theta - c_k * delta, X) - y) ** 2).mean())
            self.executions += 2.0 * shots * len(X)
            theta = theta - a_k * ((loss_p - loss_m) / (2.0 * c_k)) * delta
            current = 0.5 * (loss_p + loss_m)
            if current < best[0]:
                best = (current, theta.copy())
        self._theta = best[1]
        self._enc, self._obs = enc, obs
        self.info.update(final_loss=best[0], n_params=n_params,
                         spsa_iters=self.cfg.qnn_iters)

    def decision_function(self, X):
        feats = entangled_features(X, self._enc, theta=self._theta)
        exact = (feats ** 2) @ self._obs
        out = sample_expectation(exact, self.cfg.sketch.shots, self.rng)
        shots = 1 if self.cfg.sketch.shots == "exact" else int(self.cfg.sketch.shots)
        self.executions += float(shots) * len(X)
        return out


# --------------------------------------------------------------------------- #
# 5. Closest-prior-art mechanism
# --------------------------------------------------------------------------- #
class EmulatorPipeline(BaseModel):
    """Nystrom with k-means landmarks plus a classical surrogate; no criterion.

    Reimplemented from the published description of the closest prior art: the
    quantum kernel is sketched on k-means landmarks and then *replaced* by a
    ridge-regression surrogate built from classical kernels, with no benefit
    criterion and no PSD repair. It isolates our two mechanisms -- the decision
    gate and the analyzed approximation -- from this pipeline's mechanism.

    Any number reported for this model is measured by us on our splits and should
    be read as a lower bound on the original method's performance.
    """

    name = "emulator_prior_art"

    def _fit(self, X, y, X_tune, y_tune):
        qfn = quantum_kernel_fn(self.cfg.encoding)
        sketch_cfg = SketchConfig(m=self.cfg.sketch.m, shots=self.cfg.sketch.shots,
                                  landmark_rule="kmeans",
                                  tau_coefficient=self.cfg.sketch.tau_coefficient,
                                  psd_repair=False)
        res = nystrom_sketch(qfn, X, sketch_cfg, self.rng)
        self.executions += res.executions
        land = res.landmarks
        dictionary = build_dictionary()
        self._dict = dictionary
        # classical surrogate: regress the quantum landmark block on classical ones
        target = qfn(X[land], X[land]).ravel()
        design = np.column_stack(
            [fn(X[land], X[land]).ravel() for _, fn in dictionary]
            + [np.ones(target.size)])
        coef, *_ = np.linalg.lstsq(design, target, rcond=None)
        self._coef = coef
        K_train = self._surrogate(X, X)
        K_tune = self._surrogate(X_tune, X) if X_tune is not None else None
        self._lam = self._tune_lambda(K_train, y, K_tune, y_tune)
        n = len(y)
        self._alpha = np.linalg.solve(K_train + self._lam * n * np.eye(n), y)
        self.info.update(lam=self._lam, n_landmarks=len(land),
                         surrogate_min_eig=res.min_eigenvalue,
                         negative_mass=res.negative_mass,
                         landmark_rule="kmeans", psd_repair=False)

    def _surrogate(self, X_new, X_train):
        if X_new is None:
            return None
        parts = [fn(X_new, X_train) for _, fn in self._dict]
        out = sum(c * P for c, P in zip(self._coef[:-1], parts))
        return out + self._coef[-1]

    def decision_function(self, X):
        return self._surrogate(X, self._X) @ self._alpha


# --------------------------------------------------------------------------- #
# Registry
# --------------------------------------------------------------------------- #
ALL_MODELS = {
    SingleClassicalKernel.name: SingleClassicalKernel,
    ClassicalMKL.name: ClassicalMKL,
    QuantumOnly.name: QuantumOnly,
    AlignmentTrainedQuantum.name: AlignmentTrainedQuantum,
    QuantumNeuralNetwork.name: QuantumNeuralNetwork,
    EmulatorPipeline.name: EmulatorPipeline,
    HybridMKL.name: HybridMKL,
    BudgetedHybridMKL.name: BudgetedHybridMKL,
}


def build_model(name: str, cfg: ModelConfig, rng: np.random.Generator) -> BaseModel:
    """Instantiate a model by registry name."""
    if name not in ALL_MODELS:
        raise ValueError(f"unknown model {name!r}; available: {sorted(ALL_MODELS)}")
    return ALL_MODELS[name](cfg, rng)
