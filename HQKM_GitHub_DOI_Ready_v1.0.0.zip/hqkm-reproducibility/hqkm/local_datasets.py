"""Validated loaders for user-supplied benchmark CSV files."""

from __future__ import annotations

from pathlib import Path
import hashlib

import numpy as np

__all__ = ["UPLOAD_MANIFEST", "load_uploaded_dataset"]


UPLOAD_MANIFEST = {
    "adult": {"filename": "adults.csv", "header": None, "target": -1,
              "status": "accepted", "reason": "UCI Adult schema; headerless"},
    "diabetes": {"filename": "diabetes.csv", "header": 0, "target": "Outcome",
                 "status": "accepted", "reason": "binary target present"},
    "ionosphere": {"filename": "ionosphere.csv", "header": None, "target": -1,
                   "status": "accepted", "reason": "UCI Ionosphere schema; headerless"},
    "spambase": {"filename": "spambase.csv", "header": 0, "target": "spam",
                 "status": "accepted", "reason": "binary target present"},
    "bank_deposit": {"filename": "bank.csv", "header": 0, "target": "deposit",
                     "status": "accepted",
                     "reason": "11,162-row Bank Deposit variant; not OpenML id=1461"},
    "qsar_biodeg": {"filename": "biodeg.csv", "header": None, "sep": ";",
                    "target": -1, "status": "accepted",
                    "reason": "QSAR biodegradation; semicolon-delimited and headerless"},
    "phoneme": {"filename": "phoneme.csv", "header": 0, "target": "Class",
                "status": "accepted", "reason": "binary phoneme task"},
    "sonar": {"filename": "sonar.csv", "header": None, "target": -1,
              "status": "accepted",
              "reason": "binary Sonar task; headerless; small-sample sensitivity set"},
    "credit_g_external": {"filename": "dataset_31_credit-g.arff",
                          "format": "arff", "target": "class",
                          "status": "accepted",
                          "reason": "OpenML/UCI German Credit; locked external test"},
    "heart_external": {"filename": "heart.csv", "header": 0,
                       "target": "target", "status": "accepted",
                       "reason": "Heart Disease variant; duplicate-reduced small-sample external test"},
    "magic_gamma_external": {"filename": "MAGIC Gamma Telescope Data.csv",
                             "header": 0, "target": "Class",
                             "status": "accepted",
                             "reason": "correct MAGIC Gamma Telescope; locked external test"},
    "magic": {"filename": "daigt_magic_generations.csv", "status": "rejected",
              "reason": "DAIGT text-generation data, not MAGIC Gamma Telescope"},
    "electricity": {"filename": "electricity.csv", "status": "rejected",
                    "reason": "utility statistics table with no binary target"},
    "miniboone": {"filename": "MiniBooNE_PID.csv", "status": "rejected",
                  "reason": "50 feature columns but no target column"},
}


def load_uploaded_dataset(root, name: str, *, deduplicate_features: bool = True):
    """Return numeric ``X, y, audit`` while preserving headerless first rows.

    Categorical expansion defines a schema but estimates no distributional
    statistics. Imputation, scaling and PCA remain train-fitted downstream.
    Duplicate feature vectors are collapsed only after conflicting-label groups
    are removed, preventing identical examples from crossing data splits.
    """
    import pandas as pd

    if name not in UPLOAD_MANIFEST:
        raise ValueError(f"unknown uploaded dataset: {name}")
    spec = UPLOAD_MANIFEST[name]
    if spec["status"] != "accepted":
        raise ValueError(f"dataset {name} rejected: {spec['reason']}")
    path = Path(root) / spec["filename"]
    if spec.get("format") == "arff":
        from scipy.io import arff
        records, _ = arff.loadarff(path)
        frame = pd.DataFrame(records)
        for col in frame.select_dtypes(include=["object"]).columns:
            frame[col] = frame[col].map(
                lambda value: value.decode() if isinstance(value, bytes) else value)
    else:
        frame = pd.read_csv(path, header=spec["header"], sep=spec.get("sep", ","),
                            skipinitialspace=True,
                            na_values=["?", " ?", "NA", "null"])
    target_col = frame.columns[spec["target"]] if isinstance(spec["target"], int) else spec["target"]
    y_raw = frame[target_col].astype(str).str.strip()
    X_frame = frame.drop(columns=[target_col]).copy()
    if y_raw.nunique(dropna=False) != 2:
        raise ValueError(f"{name} target must have exactly two classes")

    original_n = len(frame)
    conflict_rows = 0
    removed_duplicate_rows = 0
    if deduplicate_features:
        joined = X_frame.copy()
        joined["__target__"] = y_raw.to_numpy()
        group_nclass = joined.groupby(list(X_frame.columns), dropna=False)["__target__"].transform("nunique")
        conflict = group_nclass > 1
        conflict_rows = int(conflict.sum())
        X_frame, y_raw = X_frame.loc[~conflict].copy(), y_raw.loc[~conflict].copy()
        duplicated = X_frame.duplicated(keep="first")
        removed_duplicate_rows = int(duplicated.sum())
        X_frame, y_raw = X_frame.loc[~duplicated], y_raw.loc[~duplicated]

    missing_before = int(X_frame.isna().sum().sum())
    # Pandas 3 uses a dedicated ``str`` dtype by default, whereas earlier
    # versions represented the same columns as ``object``. Treat every
    # non-numeric feature as categorical so ARFF/CSV behaviour is stable
    # across the supported dependency range.
    from pandas.api.types import is_numeric_dtype
    categorical = [c for c in X_frame.columns
                   if not is_numeric_dtype(X_frame[c].dtype)]
    X_frame = pd.get_dummies(X_frame, columns=categorical, dummy_na=True,
                             dtype=float)
    X = X_frame.astype(float).to_numpy()
    labels = sorted(y_raw.unique().tolist())
    y = np.where(y_raw.to_numpy() == labels[1], 1.0, -1.0)
    audit = {
        "name": name, "path": str(path), "original_rows": original_n,
        "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
        "usable_rows": len(y), "features_after_encoding": X.shape[1],
        "classes": labels, "positive_rate": float((y > 0).mean()),
        "categorical_columns": len(categorical),
        "conflicting_duplicate_rows_removed": conflict_rows,
        "consistent_duplicate_rows_removed": removed_duplicate_rows,
        "missing_values_in_raw_features": missing_before,
        "numeric_missing_values_before_train_imputation": int(np.isnan(X).sum()),
    }
    return X, y, audit
