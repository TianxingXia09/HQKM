"""Figures for the paper, from a results JSON produced by ``run_experiments.py``.

Six figures, matching the paper's narrative order: pipeline, benefit region,
cost scaling, criterion outcome, ablation grid, and the criterion-vs-realized-
benefit scatter with the confusion quadrant coloring.
"""

from __future__ import annotations

import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

import numpy as np

__all__ = ["make_figures", "FIGURE_SPECS"]

FIGURE_SPECS = {
    "fig1_pipeline": "E-last: schematic; regenerate from README diagram",
    "fig2_benefit_region": "E1: Phi against mixing; the region where benefit is predicted",
    "fig3_scaling": "E3: executions exact vs sketch, per N and m",
    "fig4_criterion_outcome": "E1: predicted vs realized benefit, quadrant colored",
    "fig5_ablation_grid": "E2: eps_fro and drift across the (m, s) grid",
    "fig6_beta_landscape": "E4: beta_q across datasets, seeds stacked",
}


def make_figures(results_path: str, out_dir: str = "figs",
                 footer: str | None = None) -> dict[str, str]:
    """Render all data figures into ``out_dir``; returns path mapping.

    ``footer`` is stamped in small grey type at the bottom of every figure. Use
    it to carry provenance (which run produced the numbers, and any scope
    limit) into the figure itself, so a figure cannot be mistaken for a
    different run than the one that generated it.
    """
    blob = json.loads(Path(results_path).read_text(encoding="utf-8"))
    studies = blob["studies"]
    Path(out_dir).mkdir(parents=True, exist_ok=True)
    out: dict[str, str] = {}

    # ---- fig2: benefit region over mixing ------------------------------ #
    if "E1" in studies:
        rows = [r for r in studies["E1"]["rows"] if r["family"] == "S1_mixed"]
        if rows:
            mix = np.array([r["mixing"] for r in rows])
            phi = np.array([r["phi"] for r in rows])
            dacc = np.array([r["delta_accuracy"] for r in rows])
            fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(9, 3.5))
            for w in np.unique(mix):
                sel = mix == w
                ax1.errorbar(w, phi[sel].mean(), yerr=phi[sel].std(), fmt="o-",
                             color="#1f77b4", capsize=3)
                ax2.errorbar(w, dacc[sel].mean(), yerr=dacc[sel].std(), fmt="s-",
                             color="#d62728", capsize=3)
            ax1.axhline(0, color="k", lw=0.8)
            ax1.set(xlabel="mixing weight w", ylabel=r"$\Phi$", title="criterion")
            ax2.axhline(0, color="k", lw=0.8)
            ax2.set(xlabel="mixing weight w", ylabel=r"$\Delta$ accuracy",
                    title="realized benefit")
            fig.tight_layout()
            out["fig2_benefit_region"] = _save(fig, out_dir, "fig2_benefit_region", footer)

        # ---- fig4: quadrant scatter ---------------------------------- #
        # Every E1 cell, not just S1_mixed: the confusion counts and the
        # correlation printed on this panel are computed over the whole study,
        # so the scatter has to show the same population.
        all_rows = studies["E1"]["rows"]
        phi_all = np.array([r["phi"] for r in all_rows])
        dacc_all = np.array([r["delta_accuracy"] for r in all_rows])
        ok = np.isfinite(phi_all) & np.isfinite(dacc_all)
        fig, ax = plt.subplots(figsize=(4.4, 4))
        col = np.where((phi_all[ok] > 0) == (dacc_all[ok] > 0), "#2ca02c", "#d62728")
        ax.scatter(phi_all[ok], dacc_all[ok], c=col, s=28, alpha=0.8,
                   edgecolor="none")
        ax.axhline(0, color="k", lw=0.8)
        ax.axvline(0, color="k", lw=0.8)
        c = studies["E1"]["confusion"]
        ax.text(0.03, 0.97, f"TN {c['tn']}   FP {c['fp']}\nFN {c['fn']}   TP {c['tp']}",
                transform=ax.transAxes, va="top", fontsize=9,
                bbox=dict(fc="white", ec="0.7"))
        rho = studies["E1"]["spearman_phi_delta_accuracy"]
        ax.set(xlabel=r"$\Phi$ (predicted)", ylabel=r"$\Delta$ accuracy (realized)",
               title=f"Spearman $\\rho$ = {rho:.2f}")
        fig.tight_layout()
        out["fig4_criterion_outcome"] = _save(fig, out_dir, "fig4_criterion_outcome", footer)

    # ---- fig3: scaling ------------------------------------------------- #
    if "E3" in studies and studies["E3"]["rows"]:
        rows = studies["E3"]["rows"]
        Ns = sorted({r["N"] for r in rows})
        ms = sorted({r["m"] for r in rows})
        fig, ax = plt.subplots(figsize=(4.8, 3.4))
        for m in ms:
            sel = [r for r in rows if r["m"] == m]
            ax.plot([r["N"] for r in sel], [r["executions_sketch"] for r in sel],
                    "o-", label=f"sketch, m={m}")
        exact = [r["executions_exact"] for r in rows if r["m"] == ms[0]]
        Ns_e = [r["N"] for r in rows if r["m"] == ms[0]]
        ax.plot(Ns_e, exact, "k--", label="exact")
        ax.set(xlabel="N", ylabel="circuit executions", yscale="log", xscale="log")
        ax.legend(fontsize=7)
        fig.tight_layout()
        out["fig3_scaling"] = _save(fig, out_dir, "fig3_scaling", footer)

    # ---- fig5: ablation grid ------------------------------------------- #
    if "E2" in studies and studies["E2"]["rows"]:
        rows = studies["E2"]["rows"]
        ms = sorted({r["m"] for r in rows})
        shots = [s for s in ("200", "1000", "exact")
                 if any(r["shots"] == s for r in rows)]
        fig, axes = plt.subplots(1, 2, figsize=(9, 3.4))
        width = 0.8 / len(shots)
        for j, (metric, title) in enumerate((("eps_frobenius", r"$\epsilon_{Fro}$"),
                                             ("drift", r"$|d^{eff}$ drift$|$"))):
            for i, m in enumerate(ms):
                for k, s in enumerate(shots):
                    vals = [r[metric] for r in rows if r["m"] == m and r["shots"] == s]
                    if vals:
                        axes[j].bar(i + (k - len(shots) / 2 + 0.5) * width,
                                    np.mean(vals), width * 0.9,
                                    color=f"C{k}", alpha=0.85)
            axes[j].set(title=title, xlabel="landmarks $m$")
            axes[j].set_xticks(range(len(ms)), [str(m) for m in ms])
        handles = [plt.Rectangle((0, 0), 1, 1, color=f"C{k}") for k in range(len(shots))]
        fig.legend(handles, [f"s={s}" for s in shots], ncol=len(shots),
                   loc="upper center", fontsize=8, frameon=False)
        fig.tight_layout(rect=(0, 0, 1, 0.92))
        out["fig5_ablation_grid"] = _save(fig, out_dir, "fig5_ablation_grid", footer)

    # ---- fig6: beta_q landscape ----------------------------------------- #
    if "E4" in studies and studies["E4"].get("rows"):
        rows = [r for r in studies["E4"]["rows"]
                if r["model"] == "hybrid_mkl" and "info" in r
                and "beta_quantum" in r["info"]]
        if rows:
            by_ds: dict[str, list[float]] = {}
            for r in rows:
                by_ds.setdefault(r["dataset"], []).append(r["info"]["beta_quantum"])
            names = sorted(by_ds)
            fig, ax = plt.subplots(figsize=(max(4, 0.6 * len(names)), 3.2))
            ax.boxplot([by_ds[n] for n in names], tick_labels=names)
            ax.axhline(0, color="k", lw=0.8)
            ax.set(ylabel=r"$\beta_q$", title="quantum weight by dataset")
            plt.setp(ax.get_xticklabels(), rotation=30, ha="right", fontsize=7)
            fig.tight_layout()
            out["fig6_beta_landscape"] = _save(fig, out_dir, "fig6_beta_landscape", footer)

    return out


def _save(fig, out_dir: str, name: str, footer: str | None = None) -> str:
    if footer:
        fig.text(0.5, 0.002, footer, ha="center", fontsize=5.6, color="0.45")
    for ext in ("png", "pdf"):
        fig.savefig(Path(out_dir) / f"{name}.{ext}", dpi=200, bbox_inches="tight")
    plt.close(fig)
    return str(Path(out_dir) / f"{name}.png")
