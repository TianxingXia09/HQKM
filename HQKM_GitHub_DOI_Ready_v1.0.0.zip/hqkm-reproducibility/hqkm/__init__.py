"""hqkm -- hybrid quantum-classical kernel acquisition benchmark.

Public surface: dataset loading, kernel dictionaries, the quantum feature maps,
the Nystrom estimator, exploratory diagnostics, the model zoo, and metrics.
"""

from __future__ import annotations

__version__ = "0.1.0"

from .quantum import (EncodingConfig, product_kernel, entangled_kernel,
                      entangled_features, quantum_kernel_fn, apply_shot_noise,
                      sample_expectation, z0_observable)
from .kernels import (DictionaryConfig, build_dictionary, normalize_gram,
                      center_gram, alignment, effective_dimension,
                      project_simplex, solve_mkl_alignment, kernel_ridge_predict)
from .estimator import (ProgressiveNystrom, SketchConfig, SketchResult, nystrom_sketch,
                        select_landmarks, psd_repair, executions_exact,
                        executions_sketch)
from .criterion import (benefit_criterion, redundancy_certificate, bound_gap,
                        complexity_term, CriterionResult, CertificateResult)
from .datasets import (BENCHMARK_INCLUSION_RULES, INDEPENDENT_BENCHMARKS,
                       DatasetSpec, SYNTHETIC_FAMILIES, REAL_DATASETS,
                       fit_real_preprocessor, load_dataset, list_datasets,
                       make_splits, transform_real_features)
from .metrics import (classification_metrics, auc_score, roc_curve, spearman_rho,
                      paired_bootstrap_ci, wilcoxon_signed_rank, paired_t_test,
                      cohens_d, holm_bonferroni)
from .baselines import ModelConfig, ALL_MODELS, build_model
from .utility_gate import evaluate_gate, select_eta, utility_score
from .meta_gate import ClassicalPreAcquisitionGate, META_FEATURES

__all__ = [
    "__version__",
    "EncodingConfig", "product_kernel", "entangled_kernel", "entangled_features",
    "quantum_kernel_fn", "apply_shot_noise", "sample_expectation",
    "z0_observable",
    "DictionaryConfig", "build_dictionary", "normalize_gram", "center_gram",
    "alignment", "effective_dimension", "project_simplex",
    "solve_mkl_alignment", "kernel_ridge_predict",
    "SketchConfig", "SketchResult", "ProgressiveNystrom", "nystrom_sketch", "select_landmarks",
    "psd_repair", "executions_exact", "executions_sketch",
    "benefit_criterion", "redundancy_certificate", "bound_gap",
    "complexity_term", "CriterionResult", "CertificateResult",
    "DatasetSpec", "SYNTHETIC_FAMILIES", "REAL_DATASETS",
    "INDEPENDENT_BENCHMARKS", "BENCHMARK_INCLUSION_RULES", "load_dataset",
    "list_datasets", "make_splits", "fit_real_preprocessor",
    "transform_real_features",
    "classification_metrics", "auc_score", "roc_curve", "spearman_rho",
    "paired_bootstrap_ci", "wilcoxon_signed_rank", "paired_t_test", "cohens_d",
    "holm_bonferroni",
    "ModelConfig", "ALL_MODELS", "build_model",
    "utility_score", "select_eta", "evaluate_gate",
    "ClassicalPreAcquisitionGate", "META_FEATURES",
]
