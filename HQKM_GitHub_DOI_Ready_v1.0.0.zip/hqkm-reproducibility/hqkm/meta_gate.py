"""Dataset-level pre-acquisition gate using classical train/tune evidence only."""

from __future__ import annotations

from dataclasses import dataclass
import numpy as np


META_FEATURES = (
    "log_n_train", "log_n_features", "positive_rate_train",
    "class_imbalance_train", "classical_alignment",
    "classical_effective_dimension", "classical_tune_accuracy",
    "classical_tune_auc", "mean_abs_classical_margin_train",
    "mean_classical_residual_train",
)


@dataclass
class ClassicalPreAcquisitionGate:
    """Fixed ridge meta-regressor; positive predicted net value buys quantum work."""

    ridge: float = 1.0
    threshold: float = 0.0

    def fit(self, meta_rows, targets):
        X = self._matrix(meta_rows)
        y = np.asarray(targets, dtype=float)
        if len(X) != len(y) or len(y) < 2:
            raise ValueError("gate needs at least two aligned meta-training rows")
        self.mean_ = X.mean(axis=0)
        self.scale_ = X.std(axis=0)
        self.scale_[self.scale_ < 1e-12] = 1.0
        Z = (X - self.mean_) / self.scale_
        design = np.c_[np.ones(len(Z)), Z]
        penalty = np.diag(np.r_[0.0, np.full(Z.shape[1], self.ridge)])
        self.coef_ = np.linalg.solve(design.T @ design + penalty,
                                     design.T @ y)
        return self

    def predict_value(self, meta_rows):
        if not hasattr(self, "coef_"):
            raise RuntimeError("fit the gate before prediction")
        Z = (self._matrix(meta_rows) - self.mean_) / self.scale_
        return np.c_[np.ones(len(Z)), Z] @ self.coef_

    def acquire(self, meta_rows):
        return self.predict_value(meta_rows) > self.threshold

    @staticmethod
    def _matrix(meta_rows):
        rows = list(meta_rows)
        X = np.asarray([[row[name] for name in META_FEATURES] for row in rows],
                       dtype=float)
        if X.ndim != 2 or X.shape[1] != len(META_FEATURES):
            raise ValueError("invalid meta-feature matrix")
        if not np.isfinite(X).all():
            raise ValueError("meta-features must be finite")
        return X
