"""Datasets: synthetic controlled families and auto-downloading real benchmarks.

Two classes of data, for two different epistemic purposes.

**Synthetic controlled families.** Real data cannot validate the criterion,
because on real data the effective dimension of the quantum component cannot be
varied independently of everything else. The families here expose exactly the
knobs the theory talks about: a mixing parameter that sweeps the label function
from purely classical structure to structure only the quantum feature map can
express, the encoding scale, and the label-noise rate. Because the generating
kernel is known, ground truth about whether the quantum kernel *should* help is
known too.

**Real benchmarks.** Tabular, moderate-dimensional, kernel-friendly problems,
downloaded on first use and cached locally. Three are bundled with scikit-learn
(no network needed); the larger ones (N >= 10^4, the regime that differentiates
this work) come from OpenML and are cached under ``~/.hqkm_data`` by default.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field

import numpy as np

from .quantum import EncodingConfig, entangled_features, product_kernel

__all__ = [
    "DatasetSpec",
    "SYNTHETIC_FAMILIES",
    "REAL_DATASETS",
    "load_dataset",
    "list_datasets",
    "make_splits",
    "fit_real_preprocessor",
    "transform_real_features",
    "INDEPENDENT_BENCHMARKS",
    "BENCHMARK_INCLUSION_RULES",
]

CACHE_DIR = os.environ.get("HQKM_DATA_DIR", os.path.expanduser("~/.hqkm_data"))


@dataclass
class DatasetSpec:
    """Metadata recorded for every dataset, as the design requires."""

    name: str
    kind: str                 # "synthetic" | "real"
    purpose: str
    n_samples: int | None
    n_features: int | None
    source: str
    licence: str
    notes: str = ""
    expected_benefit: str | None = None   # synthetic ground truth
    meta: dict = field(default_factory=dict)


# --------------------------------------------------------------------------- #
# Synthetic controlled families
# --------------------------------------------------------------------------- #
SYNTHETIC_FAMILIES = {
    "S1_mixed": DatasetSpec(
        "S1_mixed", "synthetic",
        "criterion validity: mixing parameter sweeps classical -> quantum structure",
        None, None, "generated", "n/a",
        "labels from (1-w) * classical teacher + w * quantum teacher",
        expected_benefit="increasing in mixing weight w",
    ),
    "S2_in_rkhs": DatasetSpec(
        "S2_in_rkhs", "synthetic",
        "target lies in the quantum RKHS; benefit expected unless dictionary is informed",
        None, None, "generated", "n/a", "", expected_benefit="yes",
    ),
    "S3_entangled_anchor": DatasetSpec(
        "S3_entangled_anchor", "synthetic",
        "teacher built from entangled anchor states; classical dictionary cannot represent it",
        None, None, "generated", "n/a", "", expected_benefit="yes (strong)",
    ),
    "S4_high_freq": DatasetSpec(
        "S4_high_freq", "synthetic",
        "target outside the quantum RKHS; criterion must decline",
        None, None, "generated", "n/a", "", expected_benefit="no",
    ),
    "S5_noise": DatasetSpec(
        "S5_noise", "synthetic",
        "pure label noise; both models must fail equally and the criterion must decline",
        None, None, "generated", "n/a", "", expected_benefit="no",
    ),
}


def _classical_teacher(X: np.ndarray, rng: np.random.Generator,
                       gamma: float = 0.3) -> np.ndarray:
    """Random function drawn from an RBF RKHS via random anchor expansion."""
    anchors = rng.uniform(-np.pi, np.pi, (12, X.shape[1]))
    w = rng.normal(0.0, 1.0, len(anchors))
    d2 = ((X[:, None, :] - anchors[None, :, :]) ** 2).sum(-1)
    return np.exp(-gamma * d2) @ w


def _quantum_teacher(X: np.ndarray, cfg: EncodingConfig,
                     rng: np.random.Generator, n_anchors: int = 8) -> np.ndarray:
    """Random function in the quantum RKHS via fidelity to random anchor states."""
    anchors = rng.uniform(-np.pi, np.pi, (n_anchors, X.shape[1]))
    fx = entangled_features(X, cfg)
    fa = entangled_features(anchors, cfg)
    w = rng.normal(0.0, 1.0, n_anchors)
    return ((fx @ fa.T) ** 2) @ w


def _binarize(scores: np.ndarray, noise_rate: float,
              rng: np.random.Generator) -> np.ndarray:
    y = np.where(scores >= np.median(scores), 1.0, -1.0)
    if noise_rate > 0:
        flip = rng.random(len(y)) < noise_rate
        y[flip] *= -1.0
    return y


def make_synthetic(family: str, n_samples: int, n_features: int,
                   rng: np.random.Generator, encoding: EncodingConfig,
                   mixing: float = 0.5, noise_rate: float = 0.0):
    """Generate one synthetic family. Returns ``(X, y, spec)``."""
    X = rng.uniform(-np.pi, np.pi, (n_samples, n_features))
    if family == "S1_mixed":
        c = _classical_teacher(X, rng)
        q = _quantum_teacher(X, encoding, rng)
        c = (c - c.mean()) / (c.std() + 1e-12)
        q = (q - q.mean()) / (q.std() + 1e-12)
        scores = (1.0 - mixing) * c + mixing * q
    elif family == "S2_in_rkhs":
        scores = _quantum_teacher(X, encoding, rng, n_anchors=16)
    elif family == "S3_entangled_anchor":
        scores = _quantum_teacher(X, encoding, rng, n_anchors=6)
    elif family == "S4_high_freq":
        scores = (np.sin(3.0 * X[:, 0] * X[:, 1])
                  + 0.3 * np.sin(2.5 * X[:, min(2, n_features - 1)]))
    elif family == "S5_noise":
        scores = rng.normal(0.0, 1.0, n_samples)
    else:
        raise ValueError(f"unknown synthetic family: {family!r}")
    y = _binarize(np.asarray(scores, dtype=float), noise_rate, rng)
    spec = SYNTHETIC_FAMILIES[family]
    spec.meta = dict(mixing=mixing, noise_rate=noise_rate,
                     encoding_scale=encoding.scale, n_qubits=encoding.n_qubits)
    return X, y, spec


# --------------------------------------------------------------------------- #
# Real benchmarks (auto-download + cache)
# --------------------------------------------------------------------------- #
REAL_DATASETS = {
    # bundled with scikit-learn -- no network access required
    "breast_cancer": DatasetSpec(
        "breast_cancer", "real", "small tabular benchmark, kernel-friendly",
        569, 30, "sklearn.datasets (bundled)", "CC BY 4.0 (UCI WDBC)",
        "binary; mild class imbalance 63/37",
    ),
    "digits01": DatasetSpec(
        "digits01", "real", "small image-derived tabular benchmark",
        360, 64, "sklearn.datasets (bundled)", "CC BY 4.0 (UCI)",
        "digits 0 vs 1 subset; near-separable, acts as a sanity ceiling",
    ),
    "digits17": DatasetSpec("digits17", "real", "binary digits task", 361, 64,
        "sklearn.datasets (bundled)", "CC BY 4.0 (UCI)", "digits 1 vs 7"),
    "digits38": DatasetSpec("digits38", "real", "binary digits task", 357, 64,
        "sklearn.datasets (bundled)", "CC BY 4.0 (UCI)", "digits 3 vs 8"),
    "digits49": DatasetSpec("digits49", "real", "binary digits task", 362, 64,
        "sklearn.datasets (bundled)", "CC BY 4.0 (UCI)", "digits 4 vs 9"),
    "digits56": DatasetSpec("digits56", "real", "binary digits task", 363, 64,
        "sklearn.datasets (bundled)", "CC BY 4.0 (UCI)", "digits 5 vs 6"),
    "wine": DatasetSpec(
        "wine", "real", "small tabular benchmark", 130, 13,
        "sklearn.datasets (bundled)", "CC BY 4.0 (UCI)",
        "classes 0 vs 1 subset",
    ),
    "wine02": DatasetSpec("wine02", "real", "binary wine task", 107, 13,
        "sklearn.datasets (bundled)", "CC BY 4.0 (UCI)", "classes 0 vs 2"),
    "wine12": DatasetSpec("wine12", "real", "binary wine task", 119, 13,
        "sklearn.datasets (bundled)", "CC BY 4.0 (UCI)", "classes 1 vs 2"),
    "iris01": DatasetSpec("iris01", "real", "binary iris task", 100, 4,
        "sklearn.datasets (bundled)", "CC BY 4.0 (UCI)", "classes 0 vs 1"),
    "iris02": DatasetSpec("iris02", "real", "binary iris task", 100, 4,
        "sklearn.datasets (bundled)", "CC BY 4.0 (UCI)", "classes 0 vs 2"),
    "iris12": DatasetSpec("iris12", "real", "binary iris task", 100, 4,
        "sklearn.datasets (bundled)", "CC BY 4.0 (UCI)", "classes 1 vs 2"),
    # OpenML -- downloaded on first use, then cached
    "adult": DatasetSpec(
        "adult", "real", "N >= 10^4 tabular; kernel methods competitive",
        48842, 14, "OpenML id=1590", "CC BY 4.0",
        "income > 50K; categorical features one-hot encoded",
    ),
    "electricity": DatasetSpec(
        "electricity", "real", "N >= 10^4 tabular time-ordered benchmark",
        45312, 8, "OpenML id=151", "CC BY 4.0",
        "UP/DOWN price movement",
    ),
    "magic": DatasetSpec(
        "magic", "real", "N ~ 19k physics tabular benchmark", 19020, 10,
        "OpenML id=1120 (MagicTelescope)", "CC BY 4.0",
        "gamma vs hadron; a case where strong classical baselines are hard to beat",
    ),
    "miniboone": DatasetSpec(
        "miniboone", "real", "N >= 10^5 physics tabular benchmark", 130064, 50,
        "OpenML id=41150", "CC BY 4.0", "subsampled to the requested N",
    ),
    "credit_g": DatasetSpec(
        "credit_g", "real", "independent credit-risk benchmark", 1000, 20,
        "OpenML id=31", "see OpenML metadata", "binary; mixed numeric/categorical"),
    "diabetes": DatasetSpec(
        "diabetes", "real", "independent medical benchmark", 768, 8,
        "OpenML id=37", "see OpenML metadata", "binary"),
    "sonar": DatasetSpec(
        "sonar", "real", "independent signal benchmark", 208, 60,
        "OpenML id=40", "see OpenML metadata", "binary; retained for diversity"),
    "spambase": DatasetSpec(
        "spambase", "real", "independent email benchmark", 4601, 57,
        "OpenML id=44", "see OpenML metadata", "binary"),
    "ionosphere": DatasetSpec(
        "ionosphere", "real", "independent radar benchmark", 351, 34,
        "OpenML id=59", "see OpenML metadata", "binary"),
    "bank_marketing": DatasetSpec(
        "bank_marketing", "real", "independent marketing benchmark", 45211, 16,
        "OpenML id=1461", "see OpenML metadata", "binary; mixed numeric/categorical"),
    "phoneme": DatasetSpec(
        "phoneme", "real", "independent speech benchmark", 5404, 5,
        "OpenML id=1489", "see OpenML metadata", "binary"),
    "qsar_biodeg": DatasetSpec(
        "qsar_biodeg", "real", "independent chemistry benchmark", 1055, 41,
        "OpenML id=1494", "see OpenML metadata", "binary"),
}


# Frozen before hybrid results are inspected.  Failure to load or a classical
# pilot outside the declared accuracy band is recorded, never silently removed.
INDEPENDENT_BENCHMARKS = (
    "adult", "electricity", "magic", "miniboone", "credit_g", "diabetes",
    "sonar", "spambase", "ionosphere", "bank_marketing", "phoneme",
    "qsar_biodeg",
)
BENCHMARK_INCLUSION_RULES = {
    "task": "binary classification",
    "minimum_samples_preferred": 500,
    "classical_accuracy_pilot_band": [0.70, 0.97],
    "independence_unit": "OpenML source dataset, not class-pair task",
    "exclusion_policy": "record all failures/exclusions before hybrid evaluation",
}


def _standardize_and_reduce(X: np.ndarray, n_components: int,
                            rng: np.random.Generator) -> np.ndarray:
    """Standardize, then PCA-reduce to ``n_components`` and rescale to [-pi/2, pi/2].

    Fitted on the array passed in; callers must pass training data only when
    strict leakage control matters (see ``make_splits`` for the fitted variant).
    """
    Xs = (X - X.mean(0)) / (X.std(0) + 1e-9)
    if Xs.shape[1] > n_components:
        _, _, Vt = np.linalg.svd(Xs - Xs.mean(0), full_matrices=False)
        Xs = Xs @ Vt[:n_components].T
    elif Xs.shape[1] < n_components:
        pad = rng.normal(0.0, 1e-3, (len(Xs), n_components - Xs.shape[1]))
        Xs = np.hstack([Xs, pad])
    scale = np.abs(Xs).max() + 1e-12
    return Xs / scale * (np.pi / 2.0)


@dataclass(frozen=True)
class RealPreprocessor:
    """Train-fitted numeric preprocessing state for real benchmarks."""

    median: np.ndarray
    mean: np.ndarray
    std: np.ndarray
    components: np.ndarray | None
    n_components: int
    angle_scale: float


def fit_real_preprocessor(X_train: np.ndarray,
                          n_components: int = 6) -> RealPreprocessor:
    """Fit imputation, standardization, PCA and angle scaling on train only."""
    X = np.asarray(X_train, dtype=float)
    median = np.nanmedian(X, axis=0)
    median = np.where(np.isfinite(median), median, 0.0)
    Xi = np.where(np.isfinite(X), X, median)
    mean = Xi.mean(axis=0)
    std = Xi.std(axis=0)
    std = np.where(std > 1e-12, std, 1.0)
    Xs = (Xi - mean) / std
    components = None
    if Xs.shape[1] > n_components:
        _, _, vt = np.linalg.svd(Xs, full_matrices=False)
        components = vt[:n_components].copy()
        Xr = Xs @ components.T
    else:
        Xr = Xs
    angle_scale = max(float(np.max(np.abs(Xr))), 1e-12)
    return RealPreprocessor(median, mean, std, components,
                            n_components, angle_scale)


def transform_real_features(X: np.ndarray,
                            prep: RealPreprocessor) -> np.ndarray:
    """Apply a train-fitted real-data transform without refitting."""
    X = np.asarray(X, dtype=float)
    Xi = np.where(np.isfinite(X), X, prep.median)
    Xs = (Xi - prep.mean) / prep.std
    Xr = Xs @ prep.components.T if prep.components is not None else Xs
    if Xr.shape[1] < prep.n_components:
        Xr = np.pad(Xr, ((0, 0), (0, prep.n_components - Xr.shape[1])))
    return Xr / prep.angle_scale * (np.pi / 2.0)


def _fetch_openml_cached(name: str, data_id: int) -> tuple[np.ndarray, np.ndarray]:
    """Download from OpenML once, then serve from a local ``.npz`` cache."""
    os.makedirs(CACHE_DIR, exist_ok=True)
    path = os.path.join(CACHE_DIR, f"{name}.npz")
    if os.path.exists(path):
        blob = np.load(path, allow_pickle=False)
        return blob["X"], blob["y"]
    try:
        from sklearn.datasets import fetch_openml
    except ImportError as exc:  # pragma: no cover
        raise RuntimeError(
            f"dataset {name!r} needs scikit-learn for the initial download; "
            "install it (pip install scikit-learn) or use a bundled dataset"
        ) from exc
    frame = fetch_openml(data_id=data_id, as_frame=True, parser="auto")
    X_df = frame.data
    # one-hot encode object/category columns; median-fill numeric NaNs
    X_df = X_df.copy()
    for col in X_df.columns:
        if str(X_df[col].dtype) in ("object", "category"):
            dummies = __import__("pandas").get_dummies(X_df[col], prefix=col)
            X_df = X_df.drop(columns=[col]).join(dummies)
    # Preserve numeric missing values for train-only imputation downstream.
    # One-hot columns define the dataset schema but contain no fitted statistics.
    X = X_df.astype(float).to_numpy()
    labels = np.asarray(frame.target)
    uniq = list(dict.fromkeys(labels.tolist()))
    if len(uniq) != 2:
        keep = np.isin(labels, uniq[:2])
        X, labels = X[keep], labels[keep]
        uniq = uniq[:2]
    y = np.where(labels == uniq[1], 1.0, -1.0)
    np.savez_compressed(path, X=X, y=y)
    return X, y


def load_dataset(name: str, n_samples: int | None = None, n_features: int = 6,
                 seed: int = 0, encoding: EncodingConfig | None = None,
                 mixing: float = 0.5, noise_rate: float = 0.0,
                 preprocess: bool = True):
    """Load a dataset by name. Returns ``(X, y, spec)``.

    Synthetic names come from :data:`SYNTHETIC_FAMILIES`, real ones from
    :data:`REAL_DATASETS`. Real datasets are subsampled to ``n_samples`` when
    given, PCA-reduced to ``n_features``, and rescaled into the encoding's angle
    range so that classical kernels and the circuit see identical inputs.
    """
    rng = np.random.default_rng(seed)
    encoding = encoding or EncodingConfig()

    if name in SYNTHETIC_FAMILIES:
        return make_synthetic(name, n_samples or 1000, n_features, rng,
                              encoding, mixing, noise_rate)

    if name not in REAL_DATASETS:
        raise ValueError(f"unknown dataset {name!r}; see list_datasets()")

    spec = REAL_DATASETS[name]
    bundled = ("breast_cancer", "digits01", "digits17", "digits38",
               "digits49", "digits56", "wine", "wine02", "wine12",
               "iris01", "iris02", "iris12")
    if name in bundled:
        try:
            from sklearn import datasets as skd
        except ImportError as exc:
            raise RuntimeError(
                "bundled real datasets need scikit-learn (pip install scikit-learn)"
            ) from exc
        if name == "breast_cancer":
            data = skd.load_breast_cancer()
            X, y = data.data, np.where(data.target == 1, 1.0, -1.0)
        elif name.startswith("wine"):
            data = skd.load_wine()
            pair = (0, 1) if name == "wine" else tuple(map(int, name[-2:]))
            mask = np.isin(data.target, pair)
            X, y = data.data[mask], np.where(data.target[mask] == pair[1], 1.0, -1.0)
        elif name.startswith("iris"):
            data = skd.load_iris()
            pair = tuple(map(int, name[-2:]))
            mask = np.isin(data.target, pair)
            X, y = data.data[mask], np.where(data.target[mask] == pair[1], 1.0, -1.0)
        else:
            data = skd.load_digits()
            pair = tuple(map(int, name[-2:]))
            mask = np.isin(data.target, pair)
            X, y = data.data[mask], np.where(data.target[mask] == pair[1], 1.0, -1.0)
    else:
        ids = {"adult": 1590, "electricity": 151, "magic": 1120,
               "miniboone": 41150, "credit_g": 31, "diabetes": 37,
               "sonar": 40, "spambase": 44, "ionosphere": 59,
               "bank_marketing": 1461, "phoneme": 1489,
               "qsar_biodeg": 1494}
        X, y = _fetch_openml_cached(name, ids[name])

    if n_samples is not None and n_samples < len(y):
        idx = rng.permutation(len(y))[:n_samples]
        X, y = X[idx], y[idx]
    X = np.asarray(X, dtype=float)
    if preprocess:
        prep = fit_real_preprocessor(X, n_features)
        X = transform_real_features(X, prep)
    spec.meta = dict(n=len(y), d=X.shape[1],
                     positive_rate=float((y > 0).mean()))
    return X, y, spec


def list_datasets() -> dict[str, DatasetSpec]:
    """All available datasets, synthetic and real."""
    return {**SYNTHETIC_FAMILIES, **REAL_DATASETS}


def make_splits(y: np.ndarray, rng: np.random.Generator,
                train: float = 0.6, tune: float = 0.2):
    """Stratified train / tune / test indices.

    The tune split sets ``lambda``, ``m`` and ``s`` only. The threshold ``tau`` is
    never tuned on data -- it is an analytic quantity -- and the test split is
    touched once per seed.
    """
    idx_pos = rng.permutation(np.flatnonzero(y > 0))
    idx_neg = rng.permutation(np.flatnonzero(y <= 0))
    out: list[list[np.ndarray]] = [[], [], []]
    for pool in (idx_pos, idx_neg):
        n = len(pool)
        a, b = int(train * n), int((train + tune) * n)
        out[0].append(pool[:a])
        out[1].append(pool[a:b])
        out[2].append(pool[b:])
    return tuple(rng.permutation(np.concatenate(part)) for part in out)
