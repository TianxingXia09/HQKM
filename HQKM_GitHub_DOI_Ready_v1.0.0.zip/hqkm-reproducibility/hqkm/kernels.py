"""Classical kernel dictionary, alignment, effective dimension, and the
simplex-constrained multiple-kernel-learning solver.

The dictionary, the alignment objective, and the solver are shared verbatim by
the proposed hybrid method and by the classical-only MKL baseline. The two
differ *only* in whether the quantum kernel is present in the dictionary, which
is what makes that baseline the fair primary comparison demanded by the design.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field

import numpy as np

__all__ = [
    "DictionaryConfig",
    "rbf_kernel",
    "laplacian_kernel",
    "polynomial_kernel",
    "linear_kernel",
    "build_dictionary",
    "normalize_gram",
    "center_gram",
    "alignment",
    "effective_dimension",
    "project_simplex",
    "solve_mkl_alignment",
    "kernel_ridge_predict",
]


@dataclass
class DictionaryConfig:
    """Classical dictionary grid.

    The default grid spans three kernel families over a bandwidth range wide
    enough that the dictionary is a genuinely strong baseline; an under-tuned
    classical dictionary would inflate the apparent quantum benefit.
    """

    rbf_gammas: tuple[float, ...] = (0.02, 0.1, 0.5, 2.0)
    laplacian_gammas: tuple[float, ...] = (0.05, 0.3, 1.0)
    poly_degrees: tuple[int, ...] = (2, 3)
    include_linear: bool = True
    names: list[str] = field(default_factory=list)


# --------------------------------------------------------------------------- #
# Kernel functions
# --------------------------------------------------------------------------- #
def _sqdist(X: np.ndarray, Y: np.ndarray) -> np.ndarray:
    d2 = ((X ** 2).sum(1)[:, None] + (Y ** 2).sum(1)[None, :] - 2.0 * X @ Y.T)
    return np.clip(d2, 0.0, None)


def rbf_kernel(X, Y=None, gamma: float = 1.0) -> np.ndarray:
    Y = X if Y is None else Y
    return np.exp(-gamma * _sqdist(X, Y))


def laplacian_kernel(X, Y=None, gamma: float = 1.0) -> np.ndarray:
    Y = X if Y is None else Y
    return np.exp(-gamma * np.abs(X[:, None, :] - Y[None, :, :]).sum(-1))


def polynomial_kernel(X, Y=None, degree: int = 2, coef0: float = 1.0) -> np.ndarray:
    Y = X if Y is None else Y
    gram = (X @ Y.T + coef0) ** degree
    return gram / max(float(np.abs(gram).max()), 1e-12)


def linear_kernel(X, Y=None) -> np.ndarray:
    Y = X if Y is None else Y
    gram = X @ Y.T
    return gram / max(float(np.abs(gram).max()), 1e-12)


def build_dictionary(cfg: DictionaryConfig | None = None):
    """Return ``[(name, fn), ...]`` where each ``fn`` has signature ``(X, Y=None)``."""
    cfg = cfg or DictionaryConfig()
    entries: list[tuple[str, object]] = []
    for g in cfg.rbf_gammas:
        entries.append((f"rbf_g{g}", lambda X, Y=None, g=g: rbf_kernel(X, Y, g)))
    for g in cfg.laplacian_gammas:
        entries.append((f"lap_g{g}", lambda X, Y=None, g=g: laplacian_kernel(X, Y, g)))
    for d in cfg.poly_degrees:
        entries.append((f"poly_d{d}", lambda X, Y=None, d=d: polynomial_kernel(X, Y, d)))
    if cfg.include_linear:
        entries.append(("linear", lambda X, Y=None: linear_kernel(X, Y)))
    cfg.names = [name for name, _ in entries]
    return entries


# --------------------------------------------------------------------------- #
# Gram-matrix functionals
# --------------------------------------------------------------------------- #
def normalize_gram(K: np.ndarray) -> np.ndarray:
    """Scale to unit Frobenius norm so dictionary weights are comparable."""
    return K / max(float(np.linalg.norm(K)), 1e-12)


def center_gram(K: np.ndarray) -> np.ndarray:
    """Center a Gram matrix in feature space (used for centered alignment)."""
    n = K.shape[0]
    one = np.ones((n, n)) / n
    return K - one @ K - K @ one + one @ K @ one


def alignment(K: np.ndarray, y: np.ndarray, centered: bool = False) -> float:
    r"""Kernel--target alignment :math:`A(K,y)= y^\top K y / (\|K\|_F \|yy^\top\|_F)`.

    With ``y in {-1,+1}^n`` the target Frobenius norm is exactly ``n``.
    """
    Kc = center_gram(K) if centered else K
    denom = float(np.linalg.norm(Kc)) * float(len(y))
    return float(y @ Kc @ y) / max(denom, 1e-12)


def effective_dimension(K: np.ndarray, lam: float = 0.01) -> float:
    r""":math:`d_{\mathrm{eff}} = \sum_i w_i / (w_i + n\lambda)`.

    This is the ridge-regularized effective dimension used throughout the paper
    and the appendix; the ``n * lam`` scaling keeps it comparable across sample
    sizes.
    """
    n = K.shape[0]
    ev = np.clip(np.linalg.eigvalsh(0.5 * (K + K.T)), 0.0, None)
    return float((ev / (ev + n * lam)).sum())


# --------------------------------------------------------------------------- #
# Simplex MKL by alignment maximization
# --------------------------------------------------------------------------- #
def project_simplex(v: np.ndarray) -> np.ndarray:
    """Euclidean projection onto the probability simplex."""
    u = np.sort(v)[::-1]
    css = np.cumsum(u)
    rho = np.nonzero(u * np.arange(1, len(v) + 1) > (css - 1.0))[0][-1]
    theta = (css[rho] - 1.0) / (rho + 1.0)
    return np.clip(v - theta, 0.0, None)


def solve_mkl_alignment(grams: list[np.ndarray], y: np.ndarray,
                        iters: int = 200, lr: float = 0.05,
                        tol: float = 1e-9,
                        centered: bool = False,
                        return_history: bool = False):
    r"""Maximize :math:`A(\sum_j \beta_j K_j, y)` over the simplex.

    Projected gradient ascent. The gradient of the alignment with respect to
    ``beta_j`` is

    .. math::
        \frac{y^\top K_j y}{\|K_\beta\|_F}
        - \frac{(y^\top K_\beta y)\,\langle K_\beta, K_j\rangle}{\|K_\beta\|_F^3},

    which is what the loop below implements. Every Gram matrix is normalized to
    unit Frobenius norm first so that no kernel wins on scale alone.

    Returns
    -------
    beta : ndarray
    history : list[float], optional
        Alignment value per iteration (for convergence diagnostics).
    """
    if not grams:
        raise ValueError("empty dictionary")
    # Weight optimization must use the same alignment definition later used by
    # the criterion. Center each base kernel before objective normalization;
    # the returned weights are then applied to the original normalized Grams.
    opt_grams = [center_gram(K) if centered else K for K in grams]
    opt_grams = [normalize_gram(K) for K in opt_grams]
    beta = np.ones(len(opt_grams)) / len(opt_grams)
    history: list[float] = []
    prev = -np.inf
    for _ in range(iters):
        K_beta = sum(b * K for b, K in zip(beta, opt_grams))
        frob = max(float(np.linalg.norm(K_beta)), 1e-12)
        quad = float(y @ K_beta @ y)
        obj = quad / (frob * len(y))
        history.append(obj)
        grad = np.array([
            float(y @ K @ y) / frob - quad * float(np.sum(K_beta * K)) / frob ** 3
            for K in opt_grams
        ])
        beta = project_simplex(beta + lr * grad)
        if abs(obj - prev) < tol:
            break
        prev = obj
    return (beta, history) if return_history else beta


def kernel_ridge_predict(K_train: np.ndarray, y_train: np.ndarray,
                         K_test_train: np.ndarray, lam: float) -> np.ndarray:
    """Kernel ridge regression scores (used for accuracy and AUC)."""
    n = len(y_train)
    alpha = np.linalg.solve(K_train + lam * n * np.eye(n), y_train)
    return K_test_train @ alpha
