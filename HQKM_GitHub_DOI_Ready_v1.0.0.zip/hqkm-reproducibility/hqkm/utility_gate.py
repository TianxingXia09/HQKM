"""Budget-aware decision rules using calibration data only."""

from __future__ import annotations

import numpy as np

__all__ = ["utility_score", "select_eta", "evaluate_gate"]


def utility_score(delta_tune_accuracy, normalized_quantum_cost, eta: float):
    """Predicted net utility before test labels are observed."""
    return (np.asarray(delta_tune_accuracy, dtype=float)
            - float(eta) * np.asarray(normalized_quantum_cost, dtype=float))


def evaluate_gate(rows: list[dict], eta: float) -> dict:
    """Evaluate a fixed eta on rows not used to select it."""
    tune = np.asarray([r["delta_tune_accuracy"] for r in rows], dtype=float)
    cost = np.asarray([r.get("normalized_quantum_cost", 1.0) for r in rows],
                      dtype=float)
    outcome = np.asarray([r["delta_accuracy"] for r in rows], dtype=float)
    score = utility_score(tune, cost, eta)
    select = score > 0
    truth = outcome > 0
    tp = int(np.sum(select & truth)); fp = int(np.sum(select & ~truth))
    fn = int(np.sum(~select & truth)); tn = int(np.sum(~select & ~truth))
    delivered_gain = np.where(select, outcome, 0.0)
    delivered_net = np.where(select, outcome - eta * cost, 0.0)
    return {
        "eta": float(eta), "tp": tp, "fp": fp, "fn": fn, "tn": tn,
        "selection_rate": float(select.mean()),
        "mean_delivered_accuracy_gain": float(delivered_gain.mean()),
        "mean_delivered_net_utility": float(delivered_net.mean()),
        "oracle_accuracy_gain": float(np.maximum(outcome, 0.0).mean()),
    }


def select_eta(rows: list[dict], eta_grid) -> tuple[float, list[dict]]:
    """Select eta on calibration rows; ties prefer lower quantum use."""
    table = [evaluate_gate(rows, float(eta)) for eta in eta_grid]
    best = max(table, key=lambda r: (r["mean_delivered_net_utility"], r["eta"]))
    return best["eta"], table
