"""The benefit criterion, the redundancy certificate, and the bound gap.

Three quantities, with distinct epistemic roles:

``benefit_criterion``
    The paper's decision statistic ``Phi``. Positive-and-above-threshold means
    the quantum kernel is predicted to earn its cost. The threshold ``tau``
    remains an open analytic item; ``tau = 0`` is an honest pilot proxy and is
    reported as such.

``redundancy_certificate``
    A *converse* test, computable from the landmark block alone and therefore
    *before* the full quantum Gram is paid for. High ``R^2`` means the classical
    dictionary already emulates the quantum kernel, so it can be declined.

``bound_gap``
    The excess-risk-bound difference between the hybrid optimum and ``beta_q=0``.
    This is the pre-registered primary outcome; it depends on the
    alignment-to-risk premise still open in the appendix, so it is reported
    alongside -- never instead of -- the realized accuracy delta.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np

from .kernels import alignment, effective_dimension

__all__ = [
    "CriterionResult",
    "CertificateResult",
    "benefit_criterion",
    "redundancy_certificate",
    "bound_gap",
    "complexity_term",
]


@dataclass
class CriterionResult:
    phi: float
    delta_alignment: float
    denominator: float
    floor_active: bool
    d_eff_hybrid: float
    d_eff_classical: float


@dataclass
class CertificateResult:
    r_squared: float
    fires: bool
    coefficients: np.ndarray
    executions_spent: float


def complexity_term(K_hybrid: np.ndarray, K_classical: np.ndarray,
                    lam: float = 0.01) -> tuple[float, float, float, bool]:
    r"""Denominator of ``Phi`` with the complexity floor.

    .. math::
        D = \max\!\left(\sqrt{d_{\mathrm{eff},h}/n} - \sqrt{d_{\mathrm{eff},c}/n},
        \; 1/n\right)

    The floor exists because the two effective dimensions can be equal to within
    sampling noise, which would otherwise make ``Phi`` diverge. In the pilots the
    floor activated exactly in the emulable and informed-dictionary regimes,
    i.e. where the difference genuinely was at or below noise.
    """
    n = K_hybrid.shape[0]
    d_h = effective_dimension(K_hybrid, lam)
    d_c = effective_dimension(K_classical, lam)
    raw = math.sqrt(d_h / n) - math.sqrt(d_c / n)
    floor = 1.0 / n
    return max(raw, floor), d_h, d_c, raw <= floor


def benefit_criterion(K_classical: np.ndarray, K_hybrid: np.ndarray,
                      y: np.ndarray, lam: float = 0.01,
                      centered: bool = False) -> CriterionResult:
    r"""Compute ``Phi = Delta A / D``.

    ``Delta A`` is the alignment gained by admitting the quantum kernel into the
    dictionary, and ``D`` is the complexity price paid for it. Both Gram matrices
    must be evaluated on the *same* index set, normalized the same way.
    """
    if K_classical.shape != K_hybrid.shape:
        raise ValueError("classical and hybrid Gram matrices must match in shape")
    delta_a = alignment(K_hybrid, y, centered) - alignment(K_classical, y, centered)
    denom, d_h, d_c, floored = complexity_term(K_hybrid, K_classical, lam)
    return CriterionResult(
        phi=delta_a / denom,
        delta_alignment=delta_a,
        denominator=denom,
        floor_active=floored,
        d_eff_hybrid=d_h,
        d_eff_classical=d_c,
    )


def redundancy_certificate(quantum_landmark_gram: np.ndarray,
                           classical_landmark_grams: list[np.ndarray],
                           threshold: float = 0.99,
                           executions_spent: float = 0.0) -> CertificateResult:
    r"""Least-squares emulation of the quantum landmark Gram.

    Fits ``K_q^{(land)} ~ sum_j c_j K_j^{(land)} + c_0`` and reports ``R^2``. If
    ``R^2 >= threshold`` the quantum kernel is (on the landmark block) an affine
    combination of kernels we already have, so the certificate fires and the
    quantum kernel is declined before the remaining ``N m - m^2`` entries are
    ever measured.
    """
    target = quantum_landmark_gram.ravel()
    design = np.column_stack(
        [K.ravel() for K in classical_landmark_grams] + [np.ones(target.size)]
    )
    coef, *_ = np.linalg.lstsq(design, target, rcond=None)
    residual = target - design @ coef
    ss_res = float((residual ** 2).sum())
    ss_tot = float(((target - target.mean()) ** 2).sum())
    r2 = 1.0 - ss_res / max(ss_tot, 1e-12)
    return CertificateResult(
        r_squared=r2,
        fires=bool(r2 >= threshold),
        coefficients=coef,
        executions_spent=executions_spent,
    )


def bound_gap(K_classical: np.ndarray, K_hybrid: np.ndarray, y: np.ndarray,
              lam: float = 0.01, delta: float = 0.05,
              centered: bool = False) -> float:
    r"""Excess-risk-bound gap between the hybrid and the classical-only model.

    Uses the standard alignment-minus-complexity form

    .. math::
        \widehat{\mathcal{E}}(K) = -A(K,y)
        + \sqrt{\frac{d_{\mathrm{eff}}(K)}{n}}
        + \sqrt{\frac{\log(1/\delta)}{2n}},

    so that a *positive* return means the hybrid bound is tighter. The confidence
    term is identical for both models and cancels; it is retained for
    interpretability of the absolute values.

    Caveat carried from the appendix: the step linking alignment to excess risk
    is still an open premise, so this quantity is a *bound* comparison, not a
    risk measurement.
    """
    n = len(y)
    conf = math.sqrt(math.log(1.0 / delta) / (2.0 * n))
    e_c = (-alignment(K_classical, y, centered)
           + math.sqrt(effective_dimension(K_classical, lam) / n) + conf)
    e_h = (-alignment(K_hybrid, y, centered)
           + math.sqrt(effective_dimension(K_hybrid, lam) / n) + conf)
    return float(e_c - e_h)
